#include "SumQTrimMean.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include "string"
#include "TFile.h"
#include "TMath.h"
#include "TString.h"
#include "TCanvas.h"
#include "TGraphErrors.h"
#include "TText.h"
#include "TLine.h"
#include "TF1.h"
#include "sstream"
#include <bitset>
#include <map>


ClassImp(SumQTrimMean)

map<Int_t, Int_t>                 m_badhvsgm;
map<Int_t, Int_t>                 m_stationring_ncsc;
map<Int_t, Int_t>                 m_stationring_nsegm;
map<Int_t, Int_t>                 m_entries;
map<Int_t, Int_t>                 m_nodata;
map<Int_t, Float_t>               m_trm;
map<Int_t, Float_t>               m_trm_error;
map<Int_t, Float_t>               m_trm_entries;
map<Int_t, Int_t>                 m_trm_smallstat;
map<Int_t, Float_t>               m_mean_error;
map<Int_t, Float_t>               m_trm_for_dhv;
map<Int_t, Float_t>               m_trm_error_for_dhv;
map<Int_t, Float_t>               m_trm_entries_for_dhv;
map<Int_t, Int_t>                 m_ntrm_for_dhv;
map<Int_t, Float_t>               m_hvslopes;

map<Int_t, Double_t>              m_sum_entries;
map<Int_t, Int_t>                 m_nsgm, m_trm_norm_key;

map<Int_t, Float_t>               m_ME_trm;
map<Int_t, Float_t>               m_ME_trm_error;
map<Int_t, Float_t>               m_ME_trm_entries;
map<Int_t, Float_t>               m_ME_trm_for_dhv;
map<Int_t, Float_t>               m_ME_trm_error_for_dhv;
map<Int_t, Float_t>               m_ME_trm_entries_for_dhv;

map<Int_t, Float_t>               m_dhvALL, m_dhvALL_er; 
map<Int_t, Float_t>               m_dhvME,  m_dhvME_er;

SumQTrimMean::SumQTrimMean() { }

SumQTrimMean::~SumQTrimMean() { }

/* **************************** Setup ************************************* */

void SumQTrimMean::Setup(string inp,string badhvsgm,string cuts,Double_t fstatpar,Double_t fscale,string out)
{
  inhistname=inp;
  badhvsgmname=badhvsgm;
  outliercuts=cuts;
  statpar=fstatpar;
  scale=fscale;
  histrootname=out;
  cout<<" "<<endl;
  cout<<inhistname.c_str()<<endl;
  cout<<badhvsgmname.c_str()<<endl;
  cout<<outliercuts.c_str()<<endl;
  cout<<histrootname.c_str()<<endl;
  cout<<"Trimmed Mean stat. parameter "<< statpar<<endl;
  cout<<"Scaling factor to reduce gas gain, not implemented yet "<<scale<<endl;
  cout<<""<<endl;

  cnt_gasgaingood=0;       cnt_gasgainout=0;
  cnt_gasgainsmallstat=0; cnt_gasgainbad=0;

  fstream f_in;
  f_in.open(badhvsgmname.c_str(),ios::in);
  m_badhvsgm.clear();
  Int_t nr=0,id=0;
  Float_t dummy=0.0;
  cout<<"From "<<badhvsgmname.c_str()<<endl;
  f_in>>nr;
 
  for(Int_t i=0;i<nr;i++) {
    f_in>>id>>dummy;
    if(m_badhvsgm.find(id)==m_badhvsgm.end()) m_badhvsgm[id]=0;
    cout<<i+1<<"  "<<id<<" "<<dummy<<endl;
  }
  cnt_gasgainbad=(Int_t)m_badhvsgm.size();
  f_in.close();
  cout<<"m_badhvsgm.size() "<<m_badhvsgm.size()<<endl;
  cout<<"Total bad segments "<<cnt_gasgainbad<<endl;

  f_in.open(outliercuts.c_str(),ios::in);
    f_in>>dhvME11cut[0]>>dhvME11cut[1];
    f_in>>rgg0ME11cut[0]>>rgg0ME11cut[1];
    f_in>>dhvnonME11cut[0]>>dhvnonME11cut[1];
    f_in>>rgg0nonME11innercut[0]>>rgg0nonME11innercut[1];
    f_in>>rgg0nonME11outercut[0]>>rgg0nonME11outercut[1];
  f_in.close();

  cout<<endl;
  cout<<"Outlier cuts "<<endl;
  cout<<"dhvME11cut          "<<dhvME11cut[0]<<" "<<dhvME11cut[1]<<endl;
  cout<<"rgg0ME11cut         "<<rgg0ME11cut[0]<<" "<<rgg0ME11cut[1]<<endl;
  cout<<"dhvnonME11cut       "<<dhvnonME11cut[0]<<" "<<dhvnonME11cut[1]<<endl;
  cout<<"rgg0nonME11innercut "<<rgg0nonME11innercut[0]<<" "<<rgg0nonME11innercut[1]<<endl;
  cout<<"rgg0nonME11outercut "<<rgg0nonME11outercut[0]<<" "<<rgg0nonME11outercut[1]<<endl;
 
//*******************************************************************
//CSC        ME11  ME12   ME13    ME21  ME31  ME41  ME234/2 
//# HV segm   1      3      3      3     3     3     5
//******************************************************************

  Int_t cntype[9]={11,12,13,21,22,31,32,41,42};
  Int_t cnsegm[9]={ 1, 3, 3, 3, 5, 3, 5, 3, 5}; // # of HV segments per layer
  Int_t cncsc[9]= {36,36,36,18,36,18,36,18,36}; // # of CSCs per ring/station
  for(Int_t i=0;i<9;i++) {
    ntype[i]=cntype[i];
    nsegm[i]=cnsegm[i];
    ncsc[i]=cncsc[i];
  }
  
 m_stationring_ncsc.clear();
 m_stationring_nsegm.clear();
 m_trm.clear();
 m_trm_error.clear();
 m_trm_entries.clear();
 m_sum_entries.clear();  m_nsgm.clear(); m_trm_norm_key.clear();
 m_mean_error.clear();
 m_trm_for_dhv.clear();
 m_trm_error_for_dhv.clear();
 m_trm_entries_for_dhv.clear();
 m_ntrm_for_dhv.clear();
 m_entries.clear();
 m_nodata.clear();
 m_ME_trm.clear();
 m_ME_trm_error.clear();
 m_ME_trm_entries.clear();
 m_ME_trm_for_dhv.clear();
 m_ME_trm_error_for_dhv.clear();
 m_ME_trm_entries_for_dhv.clear();
 m_hvslopes.clear();

 for(Int_t i=0;i<9;i++) {
    Int_t key=ntype[i];
    if(m_stationring_ncsc.find(key)==m_stationring_ncsc.end()) {
       m_stationring_ncsc[key]=ncsc[i];
       m_stationring_nsegm[key]=nsegm[i];
       m_ME_trm_entries_for_dhv[key]=0;
       m_ME_trm_for_dhv[key]=0.0;
       m_ME_trm_error_for_dhv[key]=0.0;

       // HV slopes for 
       // ME11,ME12,ME13,ME21,ME22,ME31,ME32,ME41,ME42
       if(key==11) m_hvslopes[key]=6.262e-03;
       if(key==21 || key==31 || key==41) m_hvslopes[key]=5.193e-03;
       if(key==12 || key==13 || key==22 || key==32 || key==42) 
          m_hvslopes[key]=5.463e-03;
    }
 }

 cout<<endl;
 cout<<"HV slopes:"<<endl;
 for(Int_t i=0;i<9;i++) {
    Int_t key=ntype[i];
    cout<<key<<" "<<m_hvslopes[key]<<endl;
 }
 cout<<endl;

 cnt_hv=0;
 for(Int_t iendcap=1; iendcap<=2;iendcap++) {
    for(Int_t istation=1;istation<=4;istation++) {
        Int_t nring=2;
        if(istation == 1) nring=3;
        for(Int_t iring=1; iring<=nring;iring++) {
           Int_t keystrng=10*istation+iring;
           Int_t ncscmx=m_stationring_ncsc[keystrng];
           Int_t nsgm=m_stationring_nsegm[keystrng];
           //cout<<"iendcap istation iring ncscmx nsgm "<<iendcap<<" "<<istation<<" "<<iring<<" "<<ncscmx<<" "<<nsgm<<endl;
           Int_t key=0,key_norm=0;
           for(Int_t icsc=1;icsc<=ncscmx;icsc++) {
              for(Int_t ilayer=1; ilayer<=6;ilayer++) {
                 for(Int_t isgm=1;isgm<=nsgm;isgm++) {
		    cnt_hv++;

                    // map key for not ME11
       key=1000000*iendcap+100000*istation+10000*iring+100*icsc+10*ilayer+isgm;
       key_norm=iendcap*10000+istation*1000+iring*100+ilayer*10+isgm;
                    // map key for ME11
       if(istation ==1 && iring ==1) {
         key=key/10;
         key_norm=key_norm/10;
       }
     //key=100000*iendcap+10000*istation+1000*iring+10*icsc+ilayer;
  
                    if(m_entries.find(key)== m_entries.end()) m_entries[key]=0;

		    // make m_trm_* maps excluding bad segments 
                    Int_t key_bad=key;
		    if(m_badhvsgm.find(key_bad)==m_badhvsgm.end()) {
                      if(m_trm_entries.find(key)== m_trm_entries.end()) {
		        m_trm_entries[key]=-2.0;
		        m_trm[key]=-2.0;
                        m_trm_error[key]=-2.0;
                        m_mean_error[key]=-2.0;

                        // for normalized occupancies in HV segments/layers
                        m_sum_entries[key_norm]=0.0;
                        m_nsgm[key_norm]=0;
                        m_trm_norm_key[key]=key_norm;
		      }
		    }
		 }    // end of for(Int_t isgm=1
              } // end of for(Int_t ilayer=1
           }    // end of for(Int_t icsc=1
        } // end of for(Int_t iring=1
    } // end of for(Int_t istation=1
 } // end of for(Int_t iendcap=1
 cout<<"cnt_hv "<<cnt_hv<<endl;
 cout<<"Total segments, m_entries.size() "<<m_entries.size()<<endl;
 cout<<"Total segments excluding bad segments:"<<endl;
 cout<<"m_trm_entries.size() "<<m_trm_entries.size()<<endl;
 cout<<"m_trm.size() "<<m_trm.size()<<endl;
 cout<<"m_trm_error.size() "<<m_trm_error.size()<<endl;
 cout<<endl;
}

/* **************************** Get trimmed Mean for distribution ****  */
Double_t SumQTrimMean::GetTrimmedMean(TH1D* hist) {

        Double_t nEntries = hist->GetEntries(); 
	Double_t nBins = hist->GetNbinsX();
	Double_t sum = 0;
	Double_t sumXbin = 0;
        Int_t flag=0;

        Double_t A,B,s1,s2,spar=nEntries*statpar,
               x1,x2,xpar,xbin,sbin,dsum; 
        //cout<<"nEntries spar "<<nEntries<<" "<<spar<<endl;
	for (Int_t i = 1; i != nBins + 1; ++i) {
	        s1=sum;
                x1=hist->GetBinLowEdge(i);
                x2=x1+hist->GetBinWidth(i);
		sum += hist->GetBinContent(i);
                dsum=hist->GetBinContent(i) * hist->GetBinCenter(i);
		sumXbin += hist->GetBinContent(i) * hist->GetBinCenter(i);
                s2=sum;
                if (sum > nEntries*statpar) { flag=1; break;}
	}
	if (sum > 0 && flag==1) {
          // Int_terpolate content of the last bin
          A=(s1*x2-s2*x1)/(x2-x1); B=(s2-s1)/(x2-x1);
          xpar=(spar-A)/B;
          xbin=(xpar-x1)/2.0+x1;
          sbin=spar-s1;
          sumXbin=sumXbin-dsum+sbin*xbin;

          return(sumXbin/spar);
       	}
	else return -1;
}

/* ************** Get trimmed Mean error for distribution ****  */
Double_t SumQTrimMean::GetTrimmedMeanError(TH1D* hist) {

	Double_t nEntries = hist->GetEntries();
	Double_t nBins = hist->GetNbinsX();

	Double_t sum = 0;
	Double_t sum2 = 0;
	Double_t sumXbin = 0;
	Double_t Ave = 0;
	Double_t Wsumsq = 0;
	Double_t Wstdv = 0;
	for (Int_t i = 1; i != nBins + 1; ++i) {
		sum += hist->GetBinContent(i);
		sumXbin += hist->GetBinContent(i) * hist->GetBinCenter(i);

		if (sum > nEntries*statpar) break;

	}
	if (sum > 0) {
		Ave = sumXbin / sum;

		for (Int_t i = 1; i <= nBins; i++){
			sum2 += hist->GetBinContent(i);
			Wsumsq += hist->GetBinContent(i)*pow((hist->GetBinCenter(i) - Ave), 2);
			if (sum2 > nEntries*statpar) break;
		}
		Wstdv = sqrt(Wsumsq) / sum2;
		return Wstdv;
	}
	else return -1;
}

void SumQTrimMean::GetHVSegmTrMean(TFile* f_in) {

  ostringstream ss;
  m_trm_smallstat.clear();
  Int_t key=0;
  
  cnt=0;
  for(std::map<Int_t,Int_t>::iterator It=m_entries.begin(); It!=m_entries.end(); ++It) {
     key=(*It).first;
     ss.str("");                 
     ss<<"HistsSegm/"<<"SumQ_"<<key;
     TH1D *h=(TH1D*)f_in->Get(ss.str().c_str());
     if(h==0) {
       cnt_gasgainout++;
       if(m_nodata.find(key)==m_nodata.end()) {
           m_nodata[key]=0;
           cout<<key<<" no data"<<endl;
       }
     }   // end of if h==0

     if(h) {
       Int_t centries=h->GetEntries();
       m_entries[key]=centries;
       if(m_trm.find(key) != m_trm.end()) {
         Double_t trm=GetTrimmedMean(h);
         Double_t trmer=GetTrimmedMeanError(h);
         Double_t ermean=h->GetMeanError(1);
         if(trm==-1.0 ) {
           cout<<"Stat. "<<statpar<<" was not reached in  GetTrimmedMean for hist "<<ss.str().c_str()<<" with "<<centries<<" entries and ratio "<<h->Integral()/(Float_t)centries<<endl;
           cnt_gasgainsmallstat++;
	 }
         if(trm > 0.0) {
           if(centries < 1000) {
             m_trm_smallstat[key]=centries;
             cout<<key<<" entries < 1000 "<<centries<<endl;
	   }
           if(centries >= 1000) {
             m_trm[key]=(Float_t)trm;
             m_trm_error[key]=(Float_t)trmer;
             m_mean_error[key]=(Float_t)ermean;
	     m_trm_entries[key]=(Float_t)centries*statpar;
             cnt_gasgaingood++;
             cnt++;
             //cout<<cnt<<"  "<<key<<" "<<centries<<endl;
	   }
	 }
       }
     }
  } // end of It=m_entries.begin()
  cout<<"Total good segments with gas gain "<<cnt<<" from m_trm.size() "<<m_trm.size()<<endl;

  cout<<endl;
  cout<<"Segments (layers for ME1/1) with no data "<<m_nodata.size()<<endl;
  cnt_hv_nodata=0;
  for(std::map<Int_t,Int_t>::iterator It=m_nodata.begin(); It!=m_nodata.end();  ++It) {
    key=(*It).first;
    cnt_hv_nodata++;
    if(m_badhvsgm.find(key) == m_badhvsgm.end())
    cout<<cnt_hv_nodata<<"  "<<key<<" "<<(*It).second<<endl;
    if(m_badhvsgm.find(key) != m_badhvsgm.end())
      cout<<cnt_hv_nodata<<"  "<<key<<" "<<(*It).second<<"        also listed as bad"<<endl;
  }
  cout<<"Total HV channels with no data "<<cnt_hv_nodata<<endl;
  cout<<endl;
  cout<<"Segments with entries < 1000 "<<m_trm_smallstat.size()<<endl;
  Int_t cnt_less_1000=0;
  for(std::map<Int_t,Int_t>::iterator It=m_trm_smallstat.begin(); It!=m_trm_smallstat.end();  ++It) {
     cnt_less_1000++;
     cout<<cnt_less_1000<<"  "<<(*It).first<<" "<<(*It).second<<endl;
  }
  cout<<endl;

  // ME11-ME42 gas gain as Trimmed Mean
  cout<<endl;
  cout<<"ME11-ME42 gas gains (from Hists/SumQ_*), error, entries:"<<endl;
  for(std::map<Int_t,Float_t>::iterator It=m_ME_trm_entries_for_dhv.begin(); It!=m_ME_trm_entries_for_dhv.end(); ++It) {
     key=(*It).first;
     ss.str("");          
     ss<<"Hists/SumQ_"<<key;
     TH1D *h=(TH1D*)f_in->Get(ss.str().c_str());
     Int_t centries=h->GetEntries();
     Double_t trm=GetTrimmedMean(h);
     Double_t trmer=GetTrimmedMeanError(h);
         m_ME_trm_for_dhv[key]=(Float_t)trm;
         m_ME_trm_error_for_dhv[key]=(Float_t)trmer;
	 m_ME_trm_entries_for_dhv[key]=(Float_t)centries;
	 printf("%4i%10.2f%10.6f%11.3e\n",key,m_ME_trm_for_dhv[key],m_ME_trm_error_for_dhv[key],m_ME_trm_entries_for_dhv[key]);

  } // end of It=m_ME_trm_entries_for_dhv.begin()

  //
  // get reference gas gain for ME11 and 
  // global reference gas gain for non ME11
  //
  // for ME11
  ref_gasgain_me11=m_ME_trm_for_dhv[11];
  //ref_gasgain_me11_err= m_ME_trm_error_for_dhv[11];
  //ref_gasgain_me11_entries=m_ME_trm_entries_for_dhv[11];
  
  // for non ME11
  glob_ref_gasgain_non_me11_inner=0.0;
  glob_ref_gasgain_non_me11_outer=0.0;
  Float_t fcnt_inner=0.0,fcnt_outer=0.0;
  for(std::map<Int_t,Float_t>::iterator It=m_ME_trm_for_dhv.begin(); It!=m_ME_trm_for_dhv.end(); ++It) {
    key=(*It).first;
    if(key != 11) {
      if(key==21 || key==31 || key==41) {
        glob_ref_gasgain_non_me11_inner=glob_ref_gasgain_non_me11_inner+(*It).second;
        fcnt_inner=fcnt_inner+1.0;
      }
      if(key==12 || key==13 || key==22 || key==32 || key==42) {
         glob_ref_gasgain_non_me11_outer=glob_ref_gasgain_non_me11_outer+(*It).second;
        fcnt_outer=fcnt_outer+1.0;
      }
    } 
  }
  glob_ref_gasgain_non_me11_inner=glob_ref_gasgain_non_me11_inner/fcnt_inner;
  glob_ref_gasgain_non_me11_outer=glob_ref_gasgain_non_me11_outer/fcnt_outer;

  cout<<endl;
  cout<<"Global ME11 reference gas gain from /Hists/SumQ_11 "<<ref_gasgain_me11<<endl;
  cout<<"Global non ME11 reference gas gains:"<<endl;
  cout<<"for inner ME2/1,ME3/1,ME4/1, average   "<<glob_ref_gasgain_non_me11_inner<<endl;
  cout<<"for outer ME1/2,ME1/3,ME234/2, average "<<glob_ref_gasgain_non_me11_outer<<endl;
}

void SumQTrimMean::MapsToHist(HistMan* hist) {
  
  ostringstream ss,sx;
  Int_t key=0;
  cnt=0;
  for(std::map<Int_t,Int_t>::iterator It=m_entries.begin(); It!=m_entries.end(); ++It) {
     key=(*It).first;
     Float_t gasgain=-2.0;
     Float_t gasgainerror=-2.0;
     Float_t mean_error=-2.0;
     Int_t trmentries=-2;
     if(m_trm.find(key) != m_trm.end()) {
       gasgain=m_trm[key];
       gasgainerror=m_trm_error[key];
       mean_error=m_mean_error[key];
       trmentries=(Int_t)m_trm_entries[key];
     }

     //printf("%8i%3i%3i%3i%3i%3i%3i%10.2f%10.2f%10.2f%10i%10i\n",key,GetEndcapFromKey(key),GetStationFromKey(key),GetRingFromKey(key),GetCscFromKey(key),GetLayerFromKey(key),GetSegmFromKey(key),gasgain,gasgainerror,mean_error,m_entries[key],trmentries);
     
     if(gasgain > 0.0) {
       cnt++;
       Float_t x=0.0,y;
       Int_t endcp=GetEndcapFromKey(key);
       Int_t stn=GetStationFromKey(key);
       Int_t rng=GetRingFromKey(key);
       Int_t chmb=GetCscFromKey(key);
       Int_t lr=GetLayerFromKey(key);
       Int_t hvsgm=GetSegmFromKey(key);
       Int_t keystrng=10*stn+rng;
       Int_t nchmb=2*m_stationring_ncsc[keystrng];
       Int_t nhvsgm=m_stationring_nsegm[keystrng];

       Int_t nbinsx=nchmb;
       Float_t lowx=1.0;
       Float_t highx=nbinsx+1;
       if(endcp==2) x=(Float_t)(m_stationring_ncsc[keystrng]-chmb+1)+0.5;
       if(endcp==1) x=(Float_t)(m_stationring_ncsc[keystrng]+chmb)+0.5;

       Int_t nbinsy=6*nhvsgm;
       Float_t lowy=1.0;
       Float_t highy=nbinsy+1;
       y=(lr-1)*nhvsgm+hvsgm;
       if(stn==1 && rng==1) y=lr;

       ss.str("");
       ss<<"ME"<<keystrng<<"_entries";
       sx.str("");
       sx<<"ME"<<keystrng<<" CSC";
       Float_t w=m_entries[key];
       hist->fill2DHist(x,y,ss.str().c_str(),ss.str().c_str(),sx.str().c_str(),"HV segment","COLZ",nbinsx,lowx,highx,nbinsy,lowy,highy,w,"");

       w=gasgain;
       ss.str("");
       ss<<"ME"<<keystrng<<"_gasgain";
       sx.str("");
       sx<<"ME"<<keystrng<<" CSC";
       hist->fill2DHist(x,y,ss.str().c_str(),ss.str().c_str(),sx.str().c_str(),"HV segment","COLZ",nbinsx,lowx,highx,nbinsy,lowy,highy,w,"");
     }
  } // end of  for(std::map<Int_t,Float_t>::iterator It=m_entries.begin();

 cout<<"Good segments "<<cnt<<endl;
}


Int_t SumQTrimMean::GetEndcapFromKey(Int_t key) {
  Int_t endcp=0;
  if(key > 300000) endcp=key/1000000;
  if(key < 300000) endcp=key/100000;
  return endcp;
}

Int_t SumQTrimMean::GetStationFromKey(Int_t key) {
  Int_t stn=0;
  if(key > 300000) stn=key/100000 - 10*GetEndcapFromKey(key);
  if(key < 300000) stn=key/10000 - 10*GetEndcapFromKey(key);
  return stn;
}

Int_t SumQTrimMean::GetRingFromKey(Int_t key) {
  Int_t rng=0;
  if(key > 300000) 
    rng=key/10000 - (100*GetEndcapFromKey(key)+10*GetStationFromKey(key));
  if(key < 300000) 
    rng=key/1000 - (100*GetEndcapFromKey(key)+10*GetStationFromKey(key));
  return rng;
}

Int_t SumQTrimMean::GetCscFromKey(Int_t key) {
  Int_t csc=0;
  if(key > 300000)
    csc=key/100-(10000*GetEndcapFromKey(key)+1000*GetStationFromKey(key)+
                   100*GetRingFromKey(key));
   if(key < 300000)
    csc=key/10-(10000*GetEndcapFromKey(key)+1000*GetStationFromKey(key)+
                   100*GetRingFromKey(key));
  return csc;
}

Int_t SumQTrimMean::GetLayerFromKey(Int_t key) {
  Int_t layer=0;
  if(key>300000)
    layer=key/10-(100000*GetEndcapFromKey(key)+10000*GetStationFromKey(key)+
		    1000*GetRingFromKey(key)+10*GetCscFromKey(key));
  if(key < 300000)
    layer=key-(100000*GetEndcapFromKey(key)+10000*GetStationFromKey(key)+
		    1000*GetRingFromKey(key)+10*GetCscFromKey(key));
  return layer;
}

Int_t SumQTrimMean::GetSegmFromKey(Int_t key) {
  Int_t segm=0;
  if(key>300000)
     segm=key-(1000000*GetEndcapFromKey(key)+100000*GetStationFromKey(key)+
		    10000*GetRingFromKey(key)+100*GetCscFromKey(key)+
		    10*GetLayerFromKey(key));
  if(key<300000) segm=1;
  return segm;
}

/* ********************* calculate HV corrections ************************ */

void SumQTrimMean::HVCorr(HistMan *hist) {
  
  ostringstream ss;
  cout<<"Calculating HV corrections"<<endl;
  Float_t rgg0=0,gasgain=0.0,dhv=0.0,dhv_er=0.0;
  m_dhvALL.clear(); m_dhvME.clear();
  m_dhvALL_er.clear(); m_dhvME_er.clear();

  cnt=0;
  for(std::map<Int_t,Float_t>::iterator It=m_trm.begin(); It!=m_trm.end(); ++It) 
    if((*It).second >0.0) cnt++;
  cout<<"Segments with gasgain "<<cnt<<endl;

  cnt=0;
  for(std::map<Int_t,Float_t>::iterator It=m_trm.begin(); It!=m_trm.end(); ++It) {
     if((*It).second >0.0) {
       Int_t key=(*It).first;
         if(m_trm_for_dhv.find(key) == m_trm_for_dhv.end()) {
            m_trm_for_dhv[key]=(*It).second;
            m_trm_error_for_dhv[key]=m_trm_error[key];
	    m_trm_entries_for_dhv[key]=m_trm_entries[key];
	 }
     }
  }
  
  cout<<"Number of HV channels for HV correction "<<m_trm_for_dhv.size()<<endl;
  cout<<endl;

  Int_t cnt_outliers_rgg0_inner_nonME11=0, cnt_outliers_rgg0_outer_nonME11=0;
  Int_t cnt_outliers_dhv_nonME11=0;
  Int_t cnt_outliers_rgg0_ME11=0, cnt_outliers_dhv_ME11=0;
  for(std::map<Int_t,Float_t>::iterator It=m_trm_for_dhv.begin(); It!=m_trm_for_dhv.end(); ++It) {
     Int_t key=(*It).first;
     Int_t mkey=GetStationFromKey(key)*10+GetRingFromKey(key);
     if(m_ME_trm_for_dhv.find(mkey) == m_ME_trm_for_dhv.end()) cout<<"Error, wrong key for m_ME_trm_for_dhv  "<<mkey<<endl;
     gasgain=(*It).second;
     if(mkey != 11) { // ME11 is excluded when using global reference gas gain
       if(mkey==21 || mkey==31 || mkey==41) 
         glob_ref_gasgain_non_me11=glob_ref_gasgain_non_me11_inner;
       if(mkey==12 || mkey==13 || mkey==22 || mkey==32 || mkey==42)
         glob_ref_gasgain_non_me11=glob_ref_gasgain_non_me11_outer;
       rgg0=gasgain/glob_ref_gasgain_non_me11;
       hist->fill1DHist(rgg0,"rgg0_all_nonME11","","G/G0","Entries",4,125,0.5,3.0,1.0,"");

       if(mkey==21 || mkey==31 || mkey==41) {
         hist->fill1DHist(rgg0,"rgg0_inner_nonME11","","G/G0","Entries",4,125,0.5,3.0,1.0,"");
         if(rgg0 < rgg0nonME11innercut[0] || rgg0 > rgg0nonME11innercut[1]) {
           cout<<"Outliers nonME11 inner rgg0nonME11innercut "<<key<<" "<<rgg0<<"  "<< rgg0nonME11innercut[0]<<" "<< rgg0nonME11innercut[1]<<endl;
	   cnt_outliers_rgg0_inner_nonME11++;
	 }
       }
       if(mkey==12 || mkey==13 || mkey==22 || mkey==32 || mkey==42) {
         hist->fill1DHist(rgg0,"rgg0_outer_nonME11","","G/G0","Entries",4,125,0.5,3.0,1.0,"");       
         if(rgg0 < rgg0nonME11outercut[0] || rgg0 > rgg0nonME11outercut[1]) {
           cout<<"Outliers nonME11 outer rgg0nonME11outercut "<<key<<" "<<rgg0<<"  "<< rgg0nonME11outercut[0]<<" "<< rgg0nonME11outercut[1]<<endl;
	   cnt_outliers_rgg0_outer_nonME11++;
	 }
       }

       dhv=log(glob_ref_gasgain_non_me11/gasgain)/m_hvslopes[mkey];
       // for dhv_er ignore error of gas gain reference and slope  
       dhv_er=m_trm_error_for_dhv[key]/(m_hvslopes[mkey]*gasgain);
       hist->fill1DHist(dhv,"deltaHV_all_non_ME11","","HV-HV0, V","Entries",4,200,-250.0,150.0,1.0,"");
       if(dhv<dhvnonME11cut[0] || dhv>dhvnonME11cut[1]) {
         cout<<"Outliers nonME11  dhvnonME11cut "<<key<<" "<<dhv<<"  "<< dhvnonME11cut[0]<<" "<< dhvnonME11cut[1]<<endl;
	   cnt_outliers_dhv_nonME11++;
       }

       Int_t esr=0;
       if(GetEndcapFromKey(key)==1) esr=mkey;
       if(GetEndcapFromKey(key)==2) esr=-mkey;
       Int_t ind=-1;
       Int_t encpstrng[16]={-42,-41,-32,-31,-22,-21,-13,-12,12,13,21,22,31,32,41,42};
       for(Int_t i=0;i<16;i++) if(esr==encpstrng[i]) ind=i;
       if(ind>-1) {
         hist->fill2DHist(dhv,(Float_t)ind,"encpstrng_vs_deltaHV_all_non_ME11","","HV-HV0, V","-42,-41,-32,-31,-22,-21,-13,-12,12,13,21,22,31,32,41,42","COLZ",200,-250.0,150.0,16,0.0,16.0,1.0,"");
        hist->fill2DHist(rgg0,(Float_t)ind,"encpstrng_vs_rgg0_all_non_ME11","","G/G0","-42,-41,-32,-31,-22,-21,-13,-12,12,13,21,22,31,32,41,42","COLZ",125,0.5,3.0,16,0.0,16.0,1.0,""); 
       }
       if(m_dhvALL.find(key)==m_dhvALL.end()) {
         m_dhvALL[key]=dhv;
         m_dhvALL_er[key]=dhv_er;
       }
     }

     if(m_ME_trm_for_dhv.find(mkey) != m_ME_trm_for_dhv.end()) {
       rgg0=gasgain/m_ME_trm_for_dhv[mkey];
       dhv=log(m_ME_trm_for_dhv[mkey]/gasgain)/m_hvslopes[mkey];
       // for dhv_er ignore error of gas gain reference and slope  
       dhv_er=m_trm_error_for_dhv[key]/(m_hvslopes[mkey]*gasgain);
       if(mkey==11) {
         hist->fill1DHist(rgg0,"rgg0_ME_ME11","","G/G0","Entries",4,125,0.5,3.0,1.0,"");
         if(rgg0<rgg0ME11cut[0] || rgg0>rgg0ME11cut[1]) {
           cout<<"Outliers ME11 rgg0ME11cut "<<key<<" "<<rgg0<<"  "<<rgg0ME11cut[0]<<" "<<rgg0ME11cut[1]<<endl;
	   cnt_outliers_rgg0_ME11++;
         }
         hist->fill1DHist(dhv,"deltaHV_ME_ME11","","HV-HV0, V","Entries",4,200,-250.0,150.0,1.0,"");
         if(dhv<dhvME11cut[0] || dhv>dhvME11cut[1]) {
           cout<<"Outliers ME11 dhvME11cut "<<key<<" "<<dhv<<"  "<<dhvME11cut[0]<<" "<<dhvME11cut[1]<<endl;
	   cnt_outliers_dhv_ME11++;
         } 
       }
       if(mkey!=11) {
         hist->fill1DHist(rgg0,"rgg0_ME_nonME11","","G/G0","Entries",4,125,0.5,3.0,1.0,"");
         hist->fill1DHist(dhv,"deltaHV_ME_nonME11","","HV-HV0, V","Entries",4,200,-250.0,150.0,1.0,"");
       }
       if(m_dhvME.find(key)==m_dhvME.end()) {
         m_dhvME[key]=dhv;
         m_dhvME_er[key]=dhv_er;
       }
     }
  } // end of for(std::map<Int_t,Float_t>::iterator It=m_trm_for_dhv.begin()

  cout<<endl;
  cout<<"NonME11 rgg0 outliers  inner and outer "<<cnt_outliers_rgg0_inner_nonME11<<" "<<cnt_outliers_rgg0_outer_nonME11<<endl;
  cout<<"NonME11 dhv outliers                   "<<cnt_outliers_dhv_nonME11<<endl;
  cout<<"ME11 rgg0 outliers                     "<<cnt_outliers_rgg0_ME11<<endl;
  cout<<"ME11 dhv  outliers                     "<<cnt_outliers_dhv_ME11<<endl;
  cout<<endl;

  cout<<"Step 3. Non ME11 HV corrections with inner and outer"<<endl;
  cout<<"        global reference gas gains G0  "<<glob_ref_gasgain_non_me11_inner<<"  "<<glob_ref_gasgain_non_me11_outer<<endl;
  cout<<"Ref     cnt     ID      CSC      L  S  dhv     dhv       Er        G      Er  Entries   G0     Slope"<<endl;
  Float_t dhv_inner_min=9999.0, dhv_inner_max=-9999.0,
          dhv_outer_min=9999.0, dhv_outer_max=-9999.0;
  Int_t key_inner_min=0, key_inner_max=0,
        key_outer_min=0, key_outer_max=0;

  cnt=0;
  Float_t glob_ref_gasgain_me11_layer=0.0, cnt_me11_layer=0.0;
  Float_t glob_ref_gasgain_non_me11_inner_segm=0.0, cnt_non_me11_inner_segm=0.0,
          glob_ref_gasgain_non_me11_outer_segm=0.0, cnt_non_me11_outer_segm=0.0;
  for(std::map<Int_t,Float_t>::iterator It=m_trm_for_dhv.begin(); It!=m_trm_for_dhv.end(); ++It) {
     Int_t key=(*It).first;
     Int_t mkey=GetStationFromKey(key)*10+GetRingFromKey(key);
     gasgain=(*It).second;

     if(mkey==11) {
       glob_ref_gasgain_me11_layer=glob_ref_gasgain_me11_layer+gasgain;
       cnt_me11_layer=cnt_me11_layer+1.0;
     }

     if(mkey != 11) {
       
       Int_t endcp=GetEndcapFromKey(key);
       Int_t stn=GetStationFromKey(key);
       Int_t rng=GetRingFromKey(key);
       Int_t chmb=GetCscFromKey(key);
       Int_t lr=GetLayerFromKey(key);
       Int_t sgm=GetSegmFromKey(key);
       ss.str("");
       ss<<"  ME";
       if(endcp==1) ss<<"+";
       if(endcp==2) ss<<"-";
       ss<<stn<<"/"<<rng<<"/";
       if(chmb<10) ss<<"0";
       ss<<chmb<<"  "<<lr<<"  "<<sgm;
       cnt++;   
       dhv=m_dhvALL[key];
       dhv_er=m_dhvALL_er[key];
       if(mkey==21 || mkey==31 || mkey==41) {
         glob_ref_gasgain_non_me11=glob_ref_gasgain_non_me11_inner;
         if(dhv<dhv_inner_min) {dhv_inner_min=dhv; key_inner_min=key;}
         if(dhv>dhv_inner_max) {dhv_inner_max=dhv; key_inner_max=key;}
         glob_ref_gasgain_non_me11_inner_segm=
	 glob_ref_gasgain_non_me11_inner_segm  + gasgain;
	 cnt_non_me11_inner_segm=cnt_non_me11_inner_segm + 1.0;
       }
       if(mkey==12 || mkey==13 || mkey==22 || mkey==32 || mkey==42) {
         glob_ref_gasgain_non_me11=glob_ref_gasgain_non_me11_outer;
         if(dhv<dhv_outer_min) {dhv_outer_min=dhv; key_outer_min=key;}
         if(dhv>dhv_outer_max) {dhv_outer_max=dhv; key_outer_max=key;} 
         glob_ref_gasgain_non_me11_outer_segm=
	 glob_ref_gasgain_non_me11_outer_segm  + gasgain;
	 cnt_non_me11_outer_segm=cnt_non_me11_outer_segm + 1.0;        
       }
       printf("dhvG0  %4i%9i%s%5.0f%12.4e%10.3e%7.1f%7.1f%8i%7.1f%10.2e\n",cnt,key,ss.str().c_str(),dhv,dhv,dhv_er,gasgain,m_trm_error_for_dhv[key],(Int_t)m_trm_entries_for_dhv[key],glob_ref_gasgain_non_me11,m_hvslopes[mkey]);
     }
  }
  cout<<"Inner nonME11 dhv_min key_min dhv_max key_max   "<<dhv_inner_min<<" "<<
          key_inner_min<<"    "<<dhv_inner_max<<" "<<key_inner_max<<endl;
  cout<<"Outer nonME11 dhv_min key_min dhv_max key_max   "<<dhv_outer_min<<" "<<
          key_outer_min<<"    "<<dhv_outer_max<<" "<<key_outer_max<<endl;  
  cout<<endl;
  cout<<"glob_ref_gasgain_me11_layer  cnt_me11_layer "<<
         glob_ref_gasgain_me11_layer/cnt_me11_layer<<"  "<<cnt_me11_layer<<endl;
  cout<<"glob_ref_gasgain_non_me11_inner_segm   cnt_non_me11_inner_segm "<<
         glob_ref_gasgain_non_me11_inner_segm/cnt_non_me11_inner_segm<<"  "<<
         cnt_non_me11_inner_segm<<endl;
  cout<<"glob_ref_gasgain_non_me11_outer_segm   cnt_non_me11_outer_segm "<<
         glob_ref_gasgain_non_me11_outer_segm/cnt_non_me11_outer_segm<<"  "<<
         cnt_non_me11_outer_segm<<endl;
  cout<<endl;

  cout<<"Step 4. HV corrections with station/ring G0 gas gain references"<<endl;
  cout<<"Ref     cnt     ID      CSC      L  S  dhv     dhv       Er        G      Er  Entries   G0     Slope"<<endl;
  Float_t dhv_min=9999.0, dhv_max=-9999.0;
  Float_t dhv_min_ME11=9999.0, dhv_max_ME11=-9999.0;
  Int_t key_min=0,key_max=0,key_ME11_min=0,key_ME11_max=0;
  cnt=0;
  for(std::map<Int_t,Float_t>::iterator It=m_trm_for_dhv.begin(); It!=m_trm_for_dhv.end(); ++It) {
     Int_t key=(*It).first;
     Int_t mkey=GetStationFromKey(key)*10+GetRingFromKey(key);

     Int_t endcp=GetEndcapFromKey(key);
     Int_t stn=GetStationFromKey(key);
     Int_t rng=GetRingFromKey(key);
     Int_t chmb=GetCscFromKey(key);
     Int_t lr=GetLayerFromKey(key);
     Int_t sgm=GetSegmFromKey(key);
     ss.str("");
     ss<<"  ME";
     if(endcp==1) ss<<"+";
     if(endcp==2) ss<<"-";
     ss<<stn<<"/"<<rng<<"/";
     if(chmb<10) ss<<"0";
     if(mkey==11) ss<<chmb<<"  "<<lr<<"   ";
     if(mkey!=11) ss<<chmb<<"  "<<lr<<"  "<<sgm;
     gasgain=(*It).second;
     cnt++;
     dhv=m_dhvME[key];
     dhv_er=m_dhvME_er[key];
     if(mkey==11) printf("dhvME11%4i%9i%s%5.0f%12.4e%10.3e%7.1f%5.1f%8i%7.1f%10.2e\n",cnt,key,ss.str().c_str(),dhv,dhv,dhv_er,gasgain,m_trm_error_for_dhv[key],(Int_t)m_trm_entries_for_dhv[key],m_ME_trm_for_dhv[mkey],m_hvslopes[mkey]);
     if(mkey!=11) printf("dhvME  %4i%9i%s%5.0f%12.4e%10.3e%7.1f%5.1f%8i%7.1f%10.2e\n",cnt,key,ss.str().c_str(),dhv,dhv,dhv_er,gasgain,m_trm_error_for_dhv[key],(Int_t)m_trm_entries_for_dhv[key],m_ME_trm_for_dhv[mkey],m_hvslopes[mkey]);

     if(mkey!=11) {
       if(dhv<dhv_min) {dhv_min=dhv; key_min=key;}
       if(dhv>dhv_max) {dhv_max=dhv; key_max=key;}
     }
     if(mkey==11) {
       if(dhv<dhv_min_ME11) {dhv_min_ME11=dhv; key_ME11_min=key;}
       if(dhv>dhv_max_ME11) {dhv_max_ME11=dhv; key_ME11_max=key;}  
     }

     // store info for normalized occupancy
     Int_t key_norm=m_trm_norm_key[key];
     m_sum_entries[key_norm]=m_sum_entries[key_norm]+
                             (Double_t)m_trm_entries_for_dhv[key];
     m_nsgm[key_norm]= m_nsgm[key_norm]+1;
  }
  cout<<"ME11    dhv_min key_min dhv_max key_max   "<<dhv_min_ME11<<" "<<key_ME11_min<<"   "<<dhv_max_ME11<<" "<<key_ME11_max<<endl;
  cout<<"NonME11 dhv_min key_min dhv_max key_max   "<<dhv_min<<" "<<key_min<<"   "<<dhv_max<<" "<<key_max<<endl;
  cout<<endl;

  cout<<"Step 5. Normalized occupancies of HV segments/layers"<<endl; 
  cout<<"CSC/layer/HVsegm ID, Norm. occup., Error, Entries  key_norm,  Av.occup., Sum, nsgm "<<endl;
  map<Int_t, Float_t> m_aver_occup_hvsgm;
  m_aver_occup_hvsgm.clear();
  cnt=0;
  for(std::map<Int_t,Float_t>::iterator It=m_trm_for_dhv.begin(); It!=m_trm_for_dhv.end(); ++It) {
     Int_t key=(*It).first;
     Int_t key_norm=m_trm_norm_key[key];
     if( m_nsgm[key_norm]==0) cout<<"Error: key, key_norm, m_trm_norm_key "<<key<<" "<<key_norm<<" "<< m_nsgm[key_norm]<<endl;
     if( m_nsgm[key_norm]!=0) {
       cnt++;
       Float_t avoccup=(Float_t)(m_sum_entries[key_norm]/(Double_t)m_nsgm[key_norm]);
       Float_t normoccup=(Float_t)m_trm_entries_for_dhv[key]/avoccup;
       Float_t error=(TMath::Sqrt(m_trm_entries_for_dhv[key]))/avoccup;
       if(m_aver_occup_hvsgm.find(key_norm)==m_aver_occup_hvsgm.end())
         m_aver_occup_hvsgm[key_norm]=avoccup;
       hist->fill1DHist(normoccup,"normoccup","","Normalized occupancy","Entries",4,150,0.0,1.5,1.0,"NormOccup");
       Int_t mkey=GetStationFromKey(key)*10+GetRingFromKey(key);
       Int_t endcp=GetEndcapFromKey(key);
       ss.str("");
       if(endcp==1) ss<<"ME+";
       if(endcp==2) ss<<"ME-";
       ss<<mkey;
       hist->fill1DHist(normoccup,ss.str().c_str(),ss.str().c_str(),"Normalized occupancy","Entries",4,1500,0.0,1.5,1.0,"NormOccup");

       printf("Norm. occup. %5i%9i%7.3f%8.4f%8.0f%7i%12.0f%10i%4i\n",cnt,key,normoccup,error,m_trm_entries_for_dhv[key],key_norm,avoccup,(Int_t)m_sum_entries[key_norm],m_nsgm[key_norm]);
     }
  }
  cout<<endl;
  cout<<"Average per HV segment/layer occupancy"<<endl;
  Int_t key_plus,key_minus;
  Float_t maxdiff=0.0;
  for(std::map<Int_t,Float_t>::iterator It=m_aver_occup_hvsgm.begin(); It!=m_aver_occup_hvsgm.end();  ++It) {
    Int_t key_norm=(*It).first;
    Float_t occup=(*It).second;
    if(key_norm<=1116) { // for ME11
      key_plus=key_norm;
      key_minus=key_plus+1000;
      Float_t mean=(m_aver_occup_hvsgm[key_plus]+m_aver_occup_hvsgm[key_minus])/2.0;
      Float_t diff=100.0*(m_aver_occup_hvsgm[key_plus]-mean)/mean;
      diff=fabs(diff);
      if(diff > maxdiff) maxdiff=diff;
      printf("%5i%12.0f%8i%12.0f%8.2f\n",key_plus,m_aver_occup_hvsgm[key_plus],key_minus,m_aver_occup_hvsgm[key_minus],diff);
      hist->fill1DHist(diff,"ME_diff_aver","ME_diff_aver","ME_diff_aver, %","Entries",4,20,0.0,10.0,1.0,"NormOccup");
    }
    if(key_norm>=11211 && key_norm<21211) { // for nonME11
      key_plus=key_norm;
      key_minus=key_plus+10000;
      Float_t mean=(m_aver_occup_hvsgm[key_plus]+m_aver_occup_hvsgm[key_minus])/2.0;
      Float_t diff=100.0*(m_aver_occup_hvsgm[key_plus]-mean)/mean;
      diff=fabs(diff);
      if(diff > maxdiff) maxdiff=diff;
      printf("%5i%12.0f%8i%12.0f%8.2f\n",key_plus,m_aver_occup_hvsgm[key_plus],key_minus,m_aver_occup_hvsgm[key_minus],diff); 
       hist->fill1DHist(diff,"ME_diff_aver","ME_diff_aver","ME_diff_aver, %","Entries",4,20,0.0,10.0,1.0,"NormOccup");
    }
  }
  cout<<"Max. diff. "<<maxdiff<<endl;
}

/* ************************ Plot graphs *********************************** */

void SumQTrimMean::PlotGraph() {
  // ROOT file to write must be opened before calling PlotGraph()
  // ME 1/1,1/2,1/3,2/1,2/2,3/1,3/2,4/1,4/2
  // Theta angles, min,max
  Float_t theta_min[9]={ 9.5,20.7,35.5, 9.5,22.8, 9.5,20.7, 9.5,18.8};
  Float_t theta_max[9]={24.0,33.6,44.2,24.0,40.4,20.7,36.8,18.8,35.0};
  Float_t theta[9]={0.0};
  
  cout<<endl;
  cout<<"Step 6."<<endl;
  cout<<"ME Theta"<<endl;
  for(Int_t i=0;i<9;i++) {
      theta[i]=(theta_min[i]+theta_max[i])/2.0;
      cout<<theta[i]<<" ";
  }
  cout<<endl;

  // Plot Gas Gain vs ME
  TCanvas *c1 = new TCanvas("TRM_ME");
  c1->SetGridx(); c1->SetGridy();
  TGraphErrors *gr;
  Float_t x[10000],y[10000],erx[10000]={0.0},ery[10000];
  Int_t np=0;

  cout<<endl;
  cout<<"Plot graphs"<<endl;
  for(std::map<Int_t,Float_t>::iterator It=m_ME_trm_for_dhv.begin(); It!=m_ME_trm_for_dhv.end(); ++It) {
    Int_t key=(*It).first;
    if(key>0) {
      x[np]=np+1;
      y[np]=(*It).second;
      ery[np]=m_ME_trm_error_for_dhv[key];
      cout<<np+1<<" "<<key<<" "<<y[np]<<" "<<ery[np]<<endl;
      np++;
    }
  }
  cout<<endl;
  
  gr = new TGraphErrors(np,x,y,erx,ery);
  gr->SetMarkerSize(1.5);
  gr->SetMarkerStyle(20);
  gr->SetMarkerColor(kBlue);
  gr->SetLineColor(kRed);
  gr->SetLineWidth(2);
  gr->SetMinimum(0.0);
  gr->SetMaximum(650.0);
  gr->Draw("AP");
  gr->SetTitle("");
  gr->GetXaxis()->SetTitle("ME");
  gr->GetXaxis()->SetTitleSize(0.045);
  gr->GetXaxis()->SetLabelSize(0.0);
  gr->GetYaxis()->SetTitle("Charge Q, ADC channels");
  gr->GetYaxis()->SetTitleSize(0.045);
  gr->GetYaxis()->SetTitleOffset(1.0);
  gr->GetYaxis()->SetLabelSize(0.04);

   TText *t = new TText();
   t->SetTextAlign(22);
   t->SetTextSize(0.04);
   t->SetTextFont(62);
   string labels[9] = {"1/1","1/2","1/3","2/1","2/2","3/1","3/2","4/1","4/2"};
   for (Int_t i=0;i<9;i++) {
      const char *s = labels[i].c_str();
      t->DrawText(x[i],-20.0,s);  // 0.1 tuned relatively gr->SetMinimum(0.0);
   }

   Float_t yline_inner=glob_ref_gasgain_non_me11_inner,
           yline_outer=glob_ref_gasgain_non_me11_outer;
   TLine *l1;
   l1=new TLine(4.0,yline_inner,8.0,yline_inner); 
   l1->SetLineWidth(2);
   l1->SetLineColor(kRed);
   l1->Draw();
   TLine *l2;
   l2=new TLine(2.0,yline_outer,9.0,yline_outer); 
   l2->SetLineWidth(2);
   l2->SetLineColor(kBlue);
   l2->Draw();

   c1->Write();
   l1->Delete();

   // Plot Gas Gain vs Theta
   
   np=np-1; // exclude ME11
   for(Int_t i=0;i<np;i++) {
       x[i]=1.0/cos(theta[i+1]*3.1416/180.0);
       y[i]=y[i+1];
       erx[i]=0.0;
       ery[i]=ery[i+1];
   }
   
   TCanvas *c2 = new TCanvas("TRM_THETA");
   c2->SetGridx(); c2->SetGridy();
   TGraphErrors *grtheta;
   grtheta = new TGraphErrors(np,x,y,erx,ery);
   grtheta->SetMarkerSize(1.5);
   grtheta->SetMarkerStyle(20);
   grtheta->SetMarkerColor(kBlue);
   grtheta->SetMinimum(0.0);
   grtheta->SetMaximum(750.0);
   grtheta->Draw("AP");
   grtheta->SetTitle("");
   grtheta->GetXaxis()->SetTitle("1/cos(#theta)");
   grtheta->GetXaxis()->SetTitleSize(0.045);
   grtheta->GetXaxis()->SetLabelSize(0.04);
   grtheta->GetYaxis()->SetTitle("Charge Q, ADC channles");
   grtheta->GetYaxis()->SetTitleSize(0.045);
   grtheta->GetYaxis()->SetTitleOffset(1.0);
   grtheta->GetYaxis()->SetLabelSize(0.04);
   
   TF1 *func=new TF1("func","[0]*x",x[0],x[np-1]);
   grtheta->Fit(func,"F", "");
   TF1 *f=(TF1*)grtheta->GetFunction("func");
   f->SetLineColor(1);
   f->SetLineWidth(3);
   c2->Update();
   TText *txt = new TText();
   txt->SetNDC();
   txt->SetTextSize(0.045);
   txt->DrawText(0.15,0.3,"ME234/1");
   txt->DrawText(0.4,0.6,"ME1234/2");
   txt->DrawText(0.78,0.42,"ME1/3");
   c2->Write();
}
/* ************************** Analyze ************************************* */

void SumQTrimMean::Analyze(HistMan *hist) {

 TFile *f_in = new TFile(inhistname.c_str());
  
 // ***************************************************************
 // Segment gas gain as Trimmed Mean, step 1.
 // **************************************************************
 cout<<"Step 1."<<endl;
 GetHVSegmTrMean(f_in);
 f_in->Close();

 // ********************************************************************
 // Look at maps and fill hists, Step 2.
 // *********************************************************************
 
 cout<<endl;
 cout<<"Step 2."<<endl;
 //cout<<"key,encp,st,rng,csc,layer,segm,gasgain,gasgainerror,ermean,entries,trmentries "<<endl;
 MapsToHist(hist);

 // ********************************************************************
 // Find HV corrections, Steps 3-5.
 // *********************************************************************
 HVCorr(hist);

 TFile *histrootfile = new TFile(histrootname.c_str(), "RECREATE");
 hist->writeHists(histrootfile);

 // ********************************************************************
 // Plot graphs, Step 6.
 // *********************************************************************
 
 PlotGraph();
 histrootfile->Close();

 // **********************************************************************
 // end of job printout
 // *********************************************************************

 cout<<endl;
 cout<<"Count good, nodata, bad and small stat HV segments"<<endl;
 cout<<"----------------------------------------"<<endl;
 cout<<"cnt_gasgaingood           "<<cnt_gasgaingood<<endl;
 cout<<"cnt_gasgain_nodata        "<<cnt_gasgainout<<endl;
 cout<<"cnt_gasgainbad            "<<cnt_gasgainbad<<endl;
 cout<<"cnt_gasgainsmallstat      "<<cnt_gasgainsmallstat<<endl;
 cout<<"--------------------"<<endl;
 cout<<endl;

 cout<<"Total HV channels               "<<cnt_hv<<endl;
 cout<<"Channels with no data           "<<cnt_hv_nodata<<endl;
 cout<<"Bad channels                    "<<m_badhvsgm.size()<<endl;
 cout<<"Channels with stat. < 1000      "<<m_trm_smallstat.size()<<endl;
 cout<<"HV channels for HV corrections  "<<m_trm_for_dhv.size()<<endl;
 cout<<"------------------------------"<<endl;
}
