#include "AnalysisGasGain.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include "TTree.h"
#include "TFile.h"
#include <limits>
#include <map>


ClassImp(AnalysisGasGain)

std::map <Int_t, Int_t>     m_Run,m_Run_usedevents,m_Run_usedhits;
std::map <Int_t, Int_t>     m_RunEvent;
std::map <Int_t, UInt_t>    m_RunStart;
std::map <Int_t, UInt_t>    m_RunEnd;
std::map <Int_t, Int_t>     m_RunRead;

std::map <Int_t, Float_t>   m_atmpres, m_gasgain_atm_slope;

std::map <Int_t, Int_t>     m_ordstatring, m_ordencpstatring;
std::map <Int_t, Int_t>     m_nRecHitlayer;
std::map <Int_t, Int_t>     m_nRecHitchamber;

std::map <UInt_t, std::vector <Double_t> >  
                            m_cscSegments_recHitRecordX,
                            m_cscSegments_recHitRecordY;
std::map <Int_t, Int_t>     m_nsegments_chamber,m_nsegments_chamber_eff;
std::map <UInt_t, std::vector <Int_t> > m_segments_chamber_hvg_eff,
                                        m_segments_chamber_hvg_eff_final;
std::map <UInt_t, std::vector <Double_t> >  
                            m_muon_segm;
std::map <Int_t, std::vector <Double_t> >  
                            m_Single_cscSegments_recHitRecordX,
                            m_Single_cscSegments_recHitRecordY;
std::map <Int_t, std::vector <Double_t> >  
                            m_cscSegments_single_trk_recHitRecord,
                            m_cscSegments_single_trk_recHitRecord_final;
std::map<Int_t, Int_t>      m_stationring_ncsc;
std::map<Int_t, Int_t>      m_stationring_nsegm;

std::map <Int_t, Double_t>  m_csc_layer_hvsegm_Xloc,
                            m_csc_layer_hvsegm_Yloc,
                            m_csc_layer_hvsegm_SumQ;
std::map<Int_t, Int_t>      m_csc_layer_nhitsel;
std::map <Int_t, std::vector <Float_t> > m_csc_hvsgm_bound;
std::map <Int_t, Float_t>   m_csc_hvsgm_binw;
std::map<Int_t, Int_t>      m_strip_zero;

AnalysisGasGain::AnalysisGasGain() { }

AnalysisGasGain::~AnalysisGasGain() { }

/* **************************** Setup ************************************* */

void AnalysisGasGain::Setup(Int_t fstat,Int_t fprint,Int_t fatm,Int_t ftest,Int_t fhists,Int_t fresid,Int_t fhistssegm,Int_t feff,string runlist,string atmpreslist,string gasgain_atm_slope_list,string inp,string out)
{
  flag_stat=fstat;
  flag_print=fprint;
  flag_atm=fatm;
  flag_test=ftest;
  flag_hists=fhists;
  flag_resid=fresid;
  flag_histssegm=fhistssegm;
  flag_eff=feff;
  runlistname=runlist;
  atmpressname=atmpreslist;
  gasgain_atm_slope=gasgain_atm_slope_list;
  ntuplename=inp;
  histrootname=out;

  m_ordstatring.clear();
  m_ordencpstatring.clear();

  // for order numeration of endcap/station/ring to use in hists
  Int_t encpstrng[18]={242,241,232,231,222,221,213,212,211,
                       111,112,113,121,122,131,132,141,142};
  for(Int_t i=0;i<18;i++) {
     Int_t key=encpstrng[i];
     m_ordencpstatring[key]=i+1;
  }
  // for order numeration of station/ring to use in hists
  Int_t strng[10]={11,12,13,14,21,22,31,32,41,42};
  for(Int_t i=0;i<10;i++) {
     Int_t key=strng[i];
     m_ordstatring[key]=i+1; 
  }

  // mark strips in CSC station/ring having X strip=0.0
  m_strip_zero.clear();
  m_strip_zero[1101]=0; m_strip_zero[1164]=0;
  m_strip_zero[1401]=0; m_strip_zero[1448]=0;
  m_strip_zero[1201]=0; m_strip_zero[1280]=0;
  m_strip_zero[1301]=0; m_strip_zero[1364]=0;
  m_strip_zero[2101]=0; m_strip_zero[2180]=0;
  m_strip_zero[2201]=0; m_strip_zero[2280]=0;
  m_strip_zero[3101]=0; m_strip_zero[3180]=0;
  m_strip_zero[3201]=0; m_strip_zero[3280]=0;  
  m_strip_zero[4101]=0; m_strip_zero[4180]=0;
  m_strip_zero[4201]=0; m_strip_zero[4280]=0;

  // For 2D hists HV segment vs CSC in different stations/rings
  Int_t cntype[9]={11,12,13,21,22,31,32,41,42};
  Int_t nsegm[9]={ 1, 3, 3, 3, 5, 3, 5, 3, 5}; // # of HV segments per layer
  Int_t ncsc[9]= {36,36,36,18,36,18,36,18,36}; // # of CSCs per ring/station
  m_stationring_ncsc.clear();
  m_stationring_nsegm.clear();
  for(Int_t i=0;i<9;i++) {
     Int_t key=cntype[i];
     m_stationring_ncsc[key]=ncsc[i];
     m_stationring_nsegm[key]=nsegm[i];
  }

  // Initial values
  dzero3.clear();
  dinit6.clear();
  izero6.clear();
 
  for(Int_t i=0;i<3;i++) dzero3.push_back(0.0);
  for(Int_t i=0;i<6;i++) izero6.push_back(0);
  for(Int_t i=0;i<6;i++) dinit6.push_back(-999.0); 

  // counters
  nhitstotal=0;
  nhitstotalsumq=0;

// Calculate and store Yloc boundaries of the HV segments in CSC
//**************************************************
//CSC        ME12   ME13   ME21  ME31  ME41  ME234/2 
//# HV segm   3      3      3     3     3     5
//**************************************************

 const Int_t ntype=6;
 const Int_t nsegm3=3;
 const Int_t nsegm5=5;

 // Al frame height, (cm, between outer edges)
 Float_t h[ntype]={189.4, 179.3, 204.6, 184.6, 164.7, 338.0};

 // dFtoAP-distance from the narrow edge of the Al Frame to the Alignment Pin
 Float_t dftoap=3.49; // cm

 // Distances (mm) of the first (*Low) and last (*High) thick wires 
 // of the HV segment from alignment pin 
 Float_t dapme12Low[nsegm3] = { 28.5,  594.3, 1251.8},   
         dapme12High[nsegm3]= {572.2, 1229.7, 1776.6},

	 dapme13Low[nsegm3] = { 28.5,  645.3, 1151.3},   
	 dapme13High[nsegm3]= {623.1, 1129.2, 1673.2}, 

	 dapme21Low[nsegm3] = { 28.7,  724.3, 1335.7},   
	 dapme21High[nsegm3]= {702.5, 1313.9, 1928.4}, 

	 dapme31Low[nsegm3] = { 28.4,  536.9, 1135.8},   
	 dapme31High[nsegm3]= {515.0, 1114.0, 1728.5},

	 dapme41Low[nsegm3] = { 30.4,  538.9, 1038.0},   
	 dapme41High[nsegm3]= {517.0, 1016.1, 1527.7},

	 dapme234_2Low[nsegm5]={ 28.7,   847.4, 1454.3, 2061.3, 2668.2},
	 dapme234_2High[nsegm5]={825.3, 1432.2, 2039.1, 2646.1, 3262.5};

 // Calculate Y loc for HV segment boundaries (Low and High).
 // Y loc = 0 is in the symmetry center of Al frame, e.g. at h[]/2.0
 for(Int_t i=0;i<nsegm3;i++) {
   me12YlocHVsgmLow[i]    = -h[0]/2.0+dftoap+dapme12Low[i]/10.0;
   me12YlocHVsgmHigh[i]   = -h[0]/2.0+dftoap+dapme12High[i]/10.0; 

   me13YlocHVsgmLow[i]    = -h[1]/2.0+dftoap+dapme13Low[i]/10.0;
   me13YlocHVsgmHigh[i]   = -h[1]/2.0+dftoap+dapme13High[i]/10.0;

   me21YlocHVsgmLow[i]    = -h[2]/2.0+dftoap+dapme21Low[i]/10.0;
   me21YlocHVsgmHigh[i]   = -h[2]/2.0+dftoap+dapme21High[i]/10.0;

   me31YlocHVsgmLow[i]    = -h[3]/2.0+dftoap+dapme31Low[i]/10.0;
   me31YlocHVsgmHigh[i]   = -h[3]/2.0+dftoap+dapme31High[i]/10.0; 
 
   me41YlocHVsgmLow[i]    = -h[4]/2.0+dftoap+dapme41Low[i]/10.0;
   me41YlocHVsgmHigh[i]   = -h[4]/2.0+dftoap+dapme41High[i]/10.0; 
 }

 for(Int_t i=0;i<nsegm5;i++) {
   me234_2YlocHVsgmLow[i]    = -h[5]/2.0+dftoap+dapme234_2Low[i]/10.0;
   me234_2YlocHVsgmHigh[i]   = -h[5]/2.0+dftoap+dapme234_2High[i]/10.0; 
 }
  // end of Y loc HV segment boundaries calculations

 /* *********** Read list of runs into the map *************************** */
 m_Run.clear();
 fstream f_in;
 f_in.open(runlistname.c_str(),ios::in);
 Int_t nr=0,runnmb=0;
 UInt_t idum;

 f_in>>nr;
 for(Int_t i=0;i<nr;i++) {
   f_in>>runnmb>>idum>>idum; // idum - don't need start and end time...
   if(m_Run.find(runnmb)==m_Run.end()) m_Run[runnmb]=0;
 }
 f_in.close(); 

 /* *********** Read list of atm. pressure into the map *******************/
 m_atmpres.clear();
 f_in.open(atmpressname.c_str(),ios::in);
 Int_t hour=0;
 Float_t p=0;
 nr=0;
 f_in>>nr;
 for(Int_t i=0;i<nr;i++) {
   f_in>>hour>>p; 
   if(m_atmpres.find(hour)!=m_atmpres.end()) cout<<"Setup error, double atm. press. entry "<<m_atmpres[hour]<<" "<<hour<<" "<<p<<endl;
   if(m_atmpres.find(hour)==m_atmpres.end()) m_atmpres[hour]=p;
 }
 f_in.close(); 

 /* ******* Read list of gasgain vs atm. pres. slopes **********/

 m_gasgain_atm_slope.clear();
 Int_t keyslope;
 Float_t slope;
 f_in.open(gasgain_atm_slope.c_str(),ios::in);
 f_in>>Pref;  // Reference atm. pressure
 if(Pref > 0.0)
   for(Int_t i=0;i<9;i++) {
      f_in>>keyslope>>slope;
      m_gasgain_atm_slope[keyslope]=slope;
   }
 f_in.close();

 SetupPrint();
}

/* *********************** SetupPrint ************************************* */

void AnalysisGasGain::SetupPrint() {

  cout<<" "<<endl;
  cout<<runlistname.c_str()<<endl;
  cout<<atmpressname.c_str()<<endl;
  cout<<gasgain_atm_slope.c_str()<<endl;
  cout<<ntuplename.c_str()<<endl;
  cout<<histrootname.c_str()<<endl;
  cout<<flag_stat<<" "<<flag_print<<endl;
  cout<<flag_atm<<" "<<flag_test<<" "<<flag_hists<<" "<<flag_resid<<" "<<flag_histssegm<<" "<<flag_eff<<endl;
  cout<<""<<endl;

  // HV segment boundaries for maps
  m_csc_hvsgm_bound.clear();
  m_csc_hvsgm_binw.clear();
  std::vector <Float_t>  fzero2;
  fzero2.clear();
  fzero2.push_back(0.0); fzero2.push_back(0.0);

  cout<<"HV segment boundaries"<<endl;
  Float_t low,high,d;
  Int_t key;
 for(Int_t i=1;i<4;i++) {
   low=me12YlocHVsgmLow[i-1];
   high=me12YlocHVsgmHigh[i-1] ;
   d=high-low;
   printf("ME12_%1i%8.1f%8.1f%6.1f\n",i,low,high,d);
   key=120+i;
   if(m_csc_hvsgm_bound.find(key)==m_csc_hvsgm_bound.end()) {
     m_csc_hvsgm_bound[key]=fzero2;
     m_csc_hvsgm_bound[key][0]=low; m_csc_hvsgm_bound[key][1]=high;
     m_csc_hvsgm_binw[key]=10.0;
   }
 }
 for(Int_t i=1;i<4;i++) {
   low=me13YlocHVsgmLow[i-1];
   high=me13YlocHVsgmHigh[i-1] ;
   d=high-low;
   printf("ME13_%1i%8.1f%8.1f%6.1f\n",i,low,high,d);
   key=130+i;
   if(m_csc_hvsgm_bound.find(key)==m_csc_hvsgm_bound.end()) {
     m_csc_hvsgm_bound[key]=fzero2;
     m_csc_hvsgm_bound[key][0]=low; m_csc_hvsgm_bound[key][1]=high;
     m_csc_hvsgm_binw[key]=10.0;
   }
 }
 for(Int_t i=1;i<4;i++) {
   low=me21YlocHVsgmLow[i-1];
   high=me21YlocHVsgmHigh[i-1] ;
   d=high-low;
   printf("ME21_%1i%8.1f%8.1f%6.1f\n",i,low,high,d);
   key=210+i;
   if(m_csc_hvsgm_bound.find(key)==m_csc_hvsgm_bound.end()) {
     m_csc_hvsgm_bound[key]=fzero2;
     m_csc_hvsgm_bound[key][0]=low; m_csc_hvsgm_bound[key][1]=high;
     m_csc_hvsgm_binw[key]=10.0;
   }
}
 for(Int_t i=1;i<4;i++) {
   low=me31YlocHVsgmLow[i-1];
   high=me31YlocHVsgmHigh[i-1] ;
   d=high-low;
   printf("ME31_%1i%8.1f%8.1f%6.1f\n",i,low,high,d);
   key=310+i;
   if(m_csc_hvsgm_bound.find(key)==m_csc_hvsgm_bound.end()) {
     m_csc_hvsgm_bound[key]=fzero2;
     m_csc_hvsgm_bound[key][0]=low; m_csc_hvsgm_bound[key][1]=high;
     m_csc_hvsgm_binw[key]=10.0;
   }
 }
 for(Int_t i=1;i<4;i++) {
   low=me41YlocHVsgmLow[i-1];
   high=me41YlocHVsgmHigh[i-1] ;
   d=high-low;
   printf("ME41_%1i%8.1f%8.1f%6.1f\n",i,low,high,d);
   key=410+i;
   if(m_csc_hvsgm_bound.find(key)==m_csc_hvsgm_bound.end()) {
     m_csc_hvsgm_bound[key]=fzero2;
     m_csc_hvsgm_bound[key][0]=low; m_csc_hvsgm_bound[key][1]=high;
     m_csc_hvsgm_binw[key]=10.0;
   }
 }
 for(Int_t i=1;i<6;i++) {
   low=me234_2YlocHVsgmLow[i-1];
   high=me234_2YlocHVsgmHigh[i-1] ;
   d=high-low;
   printf("ME234_2_%1i%8.1f%8.1f%6.1f\n",i,low,high,d);
   key=220+i;
   if(m_csc_hvsgm_bound.find(key)==m_csc_hvsgm_bound.end()) {
     m_csc_hvsgm_bound[key]=fzero2;
     m_csc_hvsgm_bound[key][0]=low; m_csc_hvsgm_bound[key][1]=high;
     m_csc_hvsgm_binw[key]=10.0;
   }
   key=320+i;
   if(m_csc_hvsgm_bound.find(key)==m_csc_hvsgm_bound.end()) {
     m_csc_hvsgm_bound[key]=fzero2;
     m_csc_hvsgm_bound[key][0]=low; m_csc_hvsgm_bound[key][1]=high;
     m_csc_hvsgm_binw[key]=10.0;
   } 
   key=420+i;
   if(m_csc_hvsgm_bound.find(key)==m_csc_hvsgm_bound.end()) {
     m_csc_hvsgm_bound[key]=fzero2;
     m_csc_hvsgm_bound[key][0]=low; m_csc_hvsgm_bound[key][1]=high;
     m_csc_hvsgm_binw[key]=10.0;
   }
 }
 key=111; // for ME11
 if(m_csc_hvsgm_bound.find(key)==m_csc_hvsgm_bound.end()) {
     m_csc_hvsgm_bound[key]=fzero2;
     m_csc_hvsgm_bound[key][0]=-80.0; m_csc_hvsgm_bound[key][1]=80.0;
     m_csc_hvsgm_binw[key]=20.0;
 }
 cout<<endl;

  cout<<"m_Run.size() "<<m_Run.size()<<endl;
  cout<<"m_atmpres.size() "<<m_atmpres.size()<<endl;  
  cout<<"Pref, mbar and gas gain vs atm. slope B by station/ring "<<endl;
  cout<<"Pref "<<Pref<<endl;
  for(std::map<Int_t,Float_t>::iterator It=m_gasgain_atm_slope.begin(); It!=m_gasgain_atm_slope.end();++It) cout<<(*It).first<<"  "<< (*It).second<<endl;
  cout<<endl;
}

/* *********************** Find HV segment ***********************************/
Int_t  AnalysisGasGain::doHVsegment(Float_t yloc,Int_t stn,Int_t rng,Int_t layer)
{
  // Use local Y to find HV segment number.

  Int_t segment=0; //Define Segment # as 0 if not found

  const Int_t nsegm3=3;
  const Int_t nsegm5=5;

  if(stn==1 && (rng==1 || rng==4)) segment=layer; // ME11 or ME14

  if(stn==1 && rng==2) { //ME12
    for(Int_t i=0;i<nsegm3; i++)
    if((yloc >= me12YlocHVsgmLow[i]) && (yloc <= me12YlocHVsgmHigh[i]))
      segment=i+1;
  }

  if(stn==1 && rng==3) { //ME13
    for(Int_t i=0;i<nsegm3; i++)
    if((yloc >= me13YlocHVsgmLow[i]) && (yloc <= me13YlocHVsgmHigh[i]))
      segment=i+1;
  }

  if(stn==2 && rng==1) { //ME21
    for(Int_t i=0;i<nsegm3; i++)
    if((yloc >= me21YlocHVsgmLow[i]) && (yloc <= me21YlocHVsgmHigh[i]))
      segment=i+1;
  }

  if(stn==3 && rng==1) { //ME31
    for(Int_t i=0;i<nsegm3; i++)
    if((yloc >= me31YlocHVsgmLow[i]) && (yloc <= me31YlocHVsgmHigh[i]))
      segment=i+1;
  }

  if(stn==4 && rng==1) { //ME41
    for(Int_t i=0;i<nsegm3; i++)
    if((yloc >= me41YlocHVsgmLow[i]) && (yloc <= me41YlocHVsgmHigh[i]))
      segment=i+1;
  }
 
  if((stn==2 || stn==3 || stn==4) && rng==2) { //ME234/2 
    for(Int_t i=0;i<nsegm5; i++)
    if((yloc >= me234_2YlocHVsgmLow[i]) && (yloc <= me234_2YlocHVsgmHigh[i]))
      segment=i+1;
  }

  return segment;
}

/* ************************** Analyze ************************************* */

void AnalysisGasGain::Analyze(HistMan *histos) {

  CycleTree(histos);
  histos->ClearHistMaps();
}

/* *******************    GetKeyChamber ******************************* */

Int_t AnalysisGasGain::GetKeyChamber(Int_t &endcap,Int_t &station,Int_t &ring,Int_t &chamber) {
  
  Int_t key=10000*endcap+1000*station+100*ring+chamber;
  return key;
}

/* *******************    GetKeyLayer ******************************* */

Int_t AnalysisGasGain::GetKeyLayer(Int_t &endcap,Int_t &station,Int_t &ring,Int_t &chamber, Int_t & layer) {
  
  Int_t key=100000*endcap+10000*station+1000*ring+10*chamber+layer;
  return key;
}

/* *******************    GetKeySegm ******************************* */

 UInt_t AnalysisGasGain::GetKeySegm(Int_t &endcap,Int_t &station,Int_t &ring,Int_t &chamber, Int_t &segm) {
  
  UInt_t key=1000000*endcap+100000*station+10000*ring+100*chamber+segm;
  return key;
}

/* *******************    GetKeyTrkSegm ******************************* */

UInt_t AnalysisGasGain::GetKeyTrkSegm(Int_t &endcap,Int_t &station,Int_t &ring,Int_t &chamber, Int_t &trk, Int_t &segm) {
  
  UInt_t key=1000000*endcap+100000*station+10000*ring+100*chamber+10*trk+segm;
  return key;
}

/* *******************    GetRecHits ********************************** */

void AnalysisGasGain::GetRecHits(HistMan* histos) {
  ostringstream ss,sx;

  nhitstotal= nhitstotal+frecHits2D_nRecHits2D;

  for(Int_t irechit=0;irechit<frecHits2D_nRecHits2D;irechit++) {            
     
     Int_t endcap=frecHits2D_ID_endcap[irechit];
     Int_t station=frecHits2D_ID_station[irechit];
     Int_t ring=frecHits2D_ID_ring[irechit]; 
     Int_t chamber=frecHits2D_ID_chamber[irechit];
     Int_t layer=frecHits2D_ID_layer[irechit];

     if(frecHits2D_SumQ[irechit] > 0.0) nhitstotalsumq++;

     // Fill maps m_nRecHitlayer and m_nRecHitchamber
     Int_t key_layer=GetKeyLayer(endcap,station,ring,chamber,layer);
     Int_t key_chmb=GetKeyChamber(endcap,station,ring,chamber);
      
     if(m_nRecHitlayer.find(key_layer)== m_nRecHitlayer.end())
       m_nRecHitlayer[key_layer]=0;
     m_nRecHitlayer[key_layer]= m_nRecHitlayer[key_layer]+1;
     if(m_nRecHitchamber.find(key_chmb)== m_nRecHitchamber.end())
       m_nRecHitchamber[key_chmb]=0;
     m_nRecHitchamber[key_chmb]= m_nRecHitchamber[key_chmb]+1;

  } // end of for(Int_t irechit=0;irechit<frecHits2D_nRecHits2D;...)

  if(flag_test) { 
    for(std::map<Int_t,Int_t>::iterator It=m_nRecHitlayer.begin(); It!= m_nRecHitlayer.end();++It) {
       Float_t nhits=(Float_t)(*It).second;
       histos->fill1DHist(nhits,"all_nhits_per_layer","","# of RecHit2D per layer","Entries",4,100,0.0,100.0,1.0,"Test");
    }
    for(std::map<Int_t,Int_t>::iterator It=m_nRecHitchamber.begin(); It!= m_nRecHitchamber.end();++It) {
       Float_t nhits=(Float_t)(*It).second;
       histos->fill1DHist(nhits,"all_nhits_per_chamber","","# of RecHit2D per chamber","Entries",4,1000,0.0,1000.0,1.0,"Test");
    }
    histos->fill1DHist((Float_t)frecHits2D_nRecHits2D,"all_nhits_per_event","","# of RecHit2D per event","Entries",4,1000,0.0,1000.0,1.0,"Test");
  } // end of if(flag_test)
}

/* ******************** GetSegments ************************************ */

void AnalysisGasGain::GetSegments(HistMan* histos) {

  if(flag_test) histos->fill1DHist((Float_t)fcscSegments_recHitRecord_endcap->size(),"all_segments_per_event","","All segments per event","Entries",4,100,0.0,100.0,1.0,"Test");

  Int_t nhits_segm_event=0;
  Int_t nhits_segment=0,nhits_segm_SumQgt0=0;
  for(UInt_t i=0;i<fcscSegments_recHitRecord_endcap->size();i++) {

        if(i<100) { // limit 100 segments per event for key_segment

	  if(flag_test) histos->fill1DHist((Float_t)(*fcscSegments_recHitRecord_endcap)[i].size(),"all_hits_per_segment","","All hits per segment","Entries",4,10,0.0,10.0,1.0,"Test");

          // use segments with hits in 4-6 layers only
	  if((Int_t)(*fcscSegments_recHitRecord_endcap)[i].size() > 3) {
            // Among such segments choose segments having single hit in outer
            // layers
            Int_t layer_min=10, layer_max=0;
            for(UInt_t j=0;j<(*fcscSegments_recHitRecord_endcap)[i].size();j++) {
	    // here i-segment,j-hit
            Int_t layer=(Int_t)(*fcscSegments_recHitRecord_layer)[i][j];
            if(layer<layer_min) layer_min=layer;
            if(layer>layer_max) layer_max=layer;
	    }

            Int_t endcapc=(Int_t)(*fcscSegments_recHitRecord_endcap)[i][0];
            Int_t stationc=(Int_t)(*fcscSegments_recHitRecord_station)[i][0];
            Int_t ringc=(Int_t)(*fcscSegments_recHitRecord_ring)[i][0];
            Int_t chamberc=(Int_t)(*fcscSegments_recHitRecord_chamber)[i][0];
	   
            Int_t key_layer_min=GetKeyLayer(endcapc,stationc,ringc,chamberc,layer_min);
            Int_t key_layer_max=GetKeyLayer(endcapc,stationc,ringc,chamberc,layer_max);

            if(m_nRecHitlayer.find(key_layer_min)!=m_nRecHitlayer.end() && 
               m_nRecHitlayer.find(key_layer_max)!=m_nRecHitlayer.end() && 
               m_nRecHitlayer[key_layer_min]==1                         && 
               m_nRecHitlayer[key_layer_max]==1) {

            for(UInt_t j=0;j<(*fcscSegments_recHitRecord_endcap)[i].size();j++) {
	    // here i-segment,j-hit
            Int_t endcap=(Int_t)(*fcscSegments_recHitRecord_endcap)[i][j];
            Int_t station=(Int_t)(*fcscSegments_recHitRecord_station)[i][j];
            Int_t ring=(Int_t)(*fcscSegments_recHitRecord_ring)[i][j];
            Int_t chamber=(Int_t)(*fcscSegments_recHitRecord_chamber)[i][j];
            Int_t layer=(Int_t)(*fcscSegments_recHitRecord_layer)[i][j];
            Double_t localX=(*fcscSegments_recHitRecord_localX)[i][j];
            Double_t localY=(*fcscSegments_recHitRecord_localY)[i][j];

            // *** check hit in segment against hit in frecHits2D_nRecHits2D
	    // *** for hit having  SumQ<0
	    nhits_segment++;
            Int_t flaghit=0;
            for(Int_t irechit=0;irechit<frecHits2D_nRecHits2D;irechit++) {
	       if(endcap==frecHits2D_ID_endcap[irechit]    &&
                  station==frecHits2D_ID_station[irechit]  &&
                  ring==frecHits2D_ID_ring[irechit]        && 
                  chamber==frecHits2D_ID_chamber[irechit]  &&
                  layer==frecHits2D_ID_layer[irechit]) {

                  Double_t dx=localX-frecHits2D_localX[irechit];
                  Double_t dy=localY-frecHits2D_localY[irechit];
                  Double_t SumQ=frecHits2D_SumQ[irechit];
                  if(fabs(dx) < 0.0001 && fabs(dy) < 0.0001) { 
                    if(SumQ>0.0) flaghit++;
		    /*
                    if(SumQ<=0.0) {
                      Int_t key_layer=GetKeyLayer(endcap,station,ring,chamber,layer);
		      cout<<"SumQ<=0.0 "<<SumQ<<" "<<fRun<<" "<<fEvent<<" "<<key_layer<<" "<<dx<<" "<<dy<<" "<<localX<<" "<<localY<<endl;
		    }
		    */
		  }
	       }
	    } // *** end of checking hit in segment against hit in 
              // *** frecHits2D_nRecHits2D

            if(flaghit >0) nhits_segm_SumQgt0++;
            Int_t segm=i;
            UInt_t key_segment=GetKeySegm(endcap,station,ring,chamber,segm);
	    if(j==0) {
              nhits_segm_event=nhits_segm_event+(Int_t)(*fcscSegments_recHitRecord_endcap)[i].size();
              Int_t key_chamber=GetKeyChamber(endcap,station,ring,chamber);

              // count # of segments per chamber
              if(m_nsegments_chamber.find(key_chamber)==m_nsegments_chamber.end())
	        m_nsegments_chamber[key_chamber]=0;
	      m_nsegments_chamber[key_chamber]=m_nsegments_chamber[key_chamber]+1;
	    } // end of if(j==0)

            
            if(m_cscSegments_recHitRecordX.find(key_segment)==m_cscSegments_recHitRecordX.end()) {
            m_cscSegments_recHitRecordX[key_segment]=dinit6;
            m_cscSegments_recHitRecordY[key_segment]=dinit6;
	    }
            m_cscSegments_recHitRecordX[key_segment][layer-1]=localX;
            m_cscSegments_recHitRecordY[key_segment][layer-1]=localY;

	    } //end of  for(UInt_t j=0;j<fcscSegments_recHitRecord_endcap[i].size()
	    } // end of selecting outer layers with single hits

	  } // end of if segment has > 3 layers in it
	}   // end of if there is < 100 segments
  } // end of for(UInt_t i=0;i<fcscSegments_recHitRecord_endcap->size();i++)
 
     if(nhits_segment != nhits_segm_SumQgt0) cout<<"nhits_segment nhits_segm_SumQgt0 event "<<nhits_segment<<" "<<nhits_segm_SumQgt0<<" "<<fEvent<<endl;

     if(flag_test) {
       histos->fill1DHist((float)nhits_segm_event,"segment_nhits_per_event","","Segment hits per event","Entries",4,1000,0.0,1000.0,1.0,"Test");
       histos->fill1DHist((Float_t)m_nsegments_chamber.size(),"CSCs_with_segments_per_event","","# of CSCs with segments per event","Entries",4,100,0.0,100.0,1.0,"Test");
       for(std::map<Int_t,Int_t>::iterator It=m_nsegments_chamber.begin(); It!= m_nsegments_chamber.end();++It) {
          Float_t nsegm=(*It).second;
          histos->fill1DHist((Float_t)nsegm,"segments_per_chamber","","Number of segments per chamber","Entires",4,100,0.0,100.0,1.0,"Test");
       }
     } // end of if(flag_test)

     // Here make map of single (per chamber) segments 
     // m_Single_cscSegments_recHitRecordX,*Y[key_chamber] from 
     // m_cscSegments_recHitRecordX,*Y using m_nsegments_chamber[key_chamber]=1

     if(m_nsegments_chamber.size() > 0 ) {
     for(UInt_t i=0;i<fcscSegments_recHitRecord_endcap->size();i++) {
       if((Int_t)(*fcscSegments_recHitRecord_endcap)[i].size() > 3 && i<100) { 
        Int_t endcap=(Int_t)(*fcscSegments_recHitRecord_endcap)[i][0];
        Int_t station=(Int_t)(*fcscSegments_recHitRecord_station)[i][0];
        Int_t ring=(Int_t)(*fcscSegments_recHitRecord_ring)[i][0];
        Int_t chamber=(Int_t)(*fcscSegments_recHitRecord_chamber)[i][0];

        Int_t key_chmb=GetKeyChamber(endcap,station,ring,chamber);

        // check below  is commented due to selection segments with single
        // hits in outer layers
        //if(m_nsegments_chamber.find(key_chmb)==m_nsegments_chamber.end())
        //cout<<"Error, no segments for key_chmb="<<key_chmb<<" event "<<fEvent<<" "<<fcscSegments_recHitRecord_endcap->size()<<" "<<(Int_t)(*fcscSegments_recHitRecord_endcap)[i].size()<<endl;

        if(m_nsegments_chamber.find(key_chmb)!=m_nsegments_chamber.end()) {
          if(m_nsegments_chamber[key_chmb]==1) {
	    if(m_Single_cscSegments_recHitRecordX.find(key_chmb) == m_Single_cscSegments_recHitRecordX.end()) { 
              Int_t segm=i;
              UInt_t key_segment=GetKeySegm(endcap,station,ring,chamber,segm);
        // check below  is commented due to selection segments with single
        // hits in outer layers
              //if(m_cscSegments_recHitRecordX.find(key_segment)== m_cscSegments_recHitRecordX.end()) cout<<"Error: no m_cscSegments_recHitRecordX with key_segment="<<key_segment<<endl;
              if(m_cscSegments_recHitRecordX.find(key_segment)!= m_cscSegments_recHitRecordX.end()) { 
		m_Single_cscSegments_recHitRecordX[key_chmb]=m_cscSegments_recHitRecordX[key_segment];
		m_Single_cscSegments_recHitRecordY[key_chmb]=m_cscSegments_recHitRecordY[key_segment];

	      }  // end of if(m_cscSegments_recHitRecordX.find(key_segment)
	    }   // end of if(m_Single_cscSegments_recHitRecordX.find(key_chmb)
	  }  // end of if(m_nsegments_chamber[key_chmb]==1)
	}   // end of if(m_nsegments_chamber.find(key_chmb)!
       } // end of if((Int_t)(*fcscSegments_recHitRecord_endcap)[i].size() > 3)
     }  // end of for(UInt_t i=0;i<fcscSegments_recHitRecord_endcap->size()
     }  // end if(m_nsegments_chamber.size() > 0 

     if(m_Single_cscSegments_recHitRecordX.size() > 0) {
       if(flag_test) histos->fill1DHist((Float_t)m_Single_cscSegments_recHitRecordX.size(),"single_segm_chambers_per_event","","Single segment chambers per event","Entries",4,100,0.0,100.0,1.0,"Test");

       Int_t nhits_single_segm_event=0;
       for(std::map<Int_t,std::vector <Double_t> >::iterator It=m_Single_cscSegments_recHitRecordX.begin(); It!= m_Single_cscSegments_recHitRecordX.end();++It) {
          Int_t key_chmb=(*It).first;
          for(Int_t i=0;i<6;i++) if(m_Single_cscSegments_recHitRecordX[key_chmb][i] > -999.0) nhits_single_segm_event++;
       }
       if(flag_test) histos->fill1DHist((float)nhits_single_segm_event,"single_segm_rechits_per_event","","Single segment hits per event","Entries",4,100,0.0,100.0,1.0,"Test");
     }
}

/* ***********************  GetTracks ********************************* */

void AnalysisGasGain::GetTracks(HistMan* histos) {
     ostringstream ss;

     if(m_Single_cscSegments_recHitRecordX.size() > 0) {

     Int_t trackne=0;  // non empty track counter, e.g. track with CSC segments
     for(UInt_t i=0;i<fmuons_cscSegmentRecord_nRecHits->size();i++) 
        if(i<10 && (*fmuons_cscSegmentRecord_nRecHits)[i].size() > 0) 
	 // i< 10 due to use in key for map
         trackne++;

     if(flag_test) histos->fill1DHist((Float_t)trackne,"nonempty_tracks_per_event","","Number of non empty tracks per event","Entires",4,10,0.0,10.0,1.0,"Test");

     if(trackne == 1) { // use events with single muon track
     Int_t trackneindmx=0;

     for(UInt_t i=0;i<fmuons_cscSegmentRecord_nRecHits->size();i++) {
       if(i<10 && (*fmuons_cscSegmentRecord_nRecHits)[i].size() > 0) {
	 // i< 10 due to use in key for map
          if(flag_test) histos->fill1DHist((Float_t)(*fmuons_cscSegmentRecord_nRecHits)[i].size(),"segments_per_track","","Number of CSC segments per track","Entries",4,10,0.0,10.0,1.0,"Test");
         if((Int_t)i>trackneindmx) trackneindmx=(Int_t)i;

         Int_t segmindmx=0;
         // i-track,j-segment
         for(UInt_t j=0;j<(*fmuons_cscSegmentRecord_nRecHits)[i].size();j++) {
           //require j<10 due to use map key and # of layers (with hits) > 3

           if(j<10 &&
              (Int_t)(*fmuons_cscSegmentRecord_nRecHits)[i][j] > 3) { 
           if((Int_t)j>segmindmx) segmindmx=(Int_t)j;
           Int_t endcap=(Int_t)(*fmuons_cscSegmentRecord_endcap)[i][j];
           Int_t station=(Int_t)(*fmuons_cscSegmentRecord_station)[i][j];
           Int_t ring=(Int_t)(*fmuons_cscSegmentRecord_ring)[i][j];
           Int_t chamber=(Int_t)(*fmuons_cscSegmentRecord_chamber)[i][j];
           Double_t localX=(*fmuons_cscSegmentRecord_localX)[i][j];
           Double_t localY=(*fmuons_cscSegmentRecord_localY)[i][j];
           Double_t nlayers=(*fmuons_cscSegmentRecord_nRecHits)[i][j];
    
           Int_t trk=i,segm=j;
           UInt_t key_trksegm=GetKeyTrkSegm(endcap,station,ring,chamber,trk,segm);
           Int_t key_chmb=GetKeyChamber(endcap,station,ring,chamber);
           
	   if(m_nsegments_chamber.find(key_chmb) != m_nsegments_chamber.end())
             if(m_nsegments_chamber[key_chmb]==1) {
               Int_t nhit=0;
               for(Int_t k=0;k<6;k++) 
		 if(m_Single_cscSegments_recHitRecordX[key_chmb][k]>-999.0)
                   nhit++;
               if(nhit != (Int_t)nlayers) {
                 cout<<"Warning - diff. # of hits "<<nhit<<" "<<nlayers<<" "<<key_trksegm<<"  "<<key_chmb<<"  "<<fEvent<<endl;
                 if(flag_test) histos->fill1DHist((Float_t)nlayers,"nhits_ne_nlayers","","# of layers given in track segment and different from original segment","Entires",4,8,0.0,8.0,1.0,"Test");
	       }
               if(nhit==(Int_t)nlayers) {
                 if(m_Single_cscSegments_recHitRecordX.find(key_chmb)==m_Single_cscSegments_recHitRecordX.end()) cout<<" GetTracks: Error - no map element with key_chmb="<<key_chmb<<endl; // Added on Sept. 28, 2016, just in case...
                 Double_t sumx=0.0,sumy=0.0;
                 for(Int_t k=0;k<6;k++) 
		   if(m_Single_cscSegments_recHitRecordX[key_chmb][k]>-999.0) {
                      Int_t key_layer=10*key_chmb+(k+1);
                      if(m_cscSegments_single_trk_recHitRecord.find(key_layer)==m_cscSegments_single_trk_recHitRecord.end()) 
		        m_cscSegments_single_trk_recHitRecord[key_layer]=dzero3;
                      m_cscSegments_single_trk_recHitRecord[key_layer][0]=m_Single_cscSegments_recHitRecordX[key_chmb][k];
                      m_cscSegments_single_trk_recHitRecord[key_layer][1]=m_Single_cscSegments_recHitRecordY[key_chmb][k];
                      m_cscSegments_single_trk_recHitRecord[key_layer][2]=-999.0;  
                      sumx=sumx+m_Single_cscSegments_recHitRecordX[key_chmb][k];
                      sumy=sumy+m_Single_cscSegments_recHitRecordY[key_chmb][k];
		   }
                 Double_t x_aver=sumx/(Double_t)nhit;
                 Double_t y_aver=sumy/(Double_t)nhit; 

                 if(m_muon_segm.find(key_trksegm)==m_muon_segm.end())
                   m_muon_segm[key_trksegm]=dzero3;
	           m_muon_segm[key_trksegm][0]=localX;
                 m_muon_segm[key_trksegm][1]=localY;
                 m_muon_segm[key_trksegm][2]=nlayers;

		 if(flag_test) {
                 if(nhit==6) {
                   Float_t dx=(Float_t)(x_aver-localX);
                   Float_t dy=(Float_t)(y_aver-localY);
                   histos->fill1DHist(dx,"dx6","","dx, cm","Entires",4,100,-0.5,0.5,1.0,"Test");
                   histos->fill1DHist(dy,"dy6","","dy, cm","Entires",4,100,-0.5,0.5,1.0,"Test");
                   Int_t key_strng=10*station+ring;
                   histos->fill2DHist(dy,((Float_t)m_ordstatring[key_strng]+0.5),"ringstation_vs_dy","","dy, cm","Station/ring, 11,12,13,14,21,22,31,32,41,42","COLZ",100,-0.5,0.5,10,1.0,11.0,1.0,"Test");
                   histos->fill2DHist(dx,((Float_t)m_ordstatring[key_strng]+0.5),"ringstation_vs_dx","","dx, cm","Station/ring, 11,12,13,14,21,22,31,32,41,42","COLZ",100,-0.5,0.5,10,1.0,11.0,1.0,"Test");
                   Int_t statrng=10*station+ring;
                     ss.str("");
                     if( statrng==11 ||  statrng==14) {
                       ss<<"Yloc_vs_dy_ME11";
                       histos->fill2DHist(dy,y_aver,ss.str().c_str(),"","dy, cm","Yloc, cm","COLZ",25,-0.25,0.25,50,-100.0,100.0,1.0,"Test");
		     }
                     ss<<"Yloc_vs_dy_ME"<<statrng;
		     if(statrng==12 || statrng==13 || statrng==21 || statrng==22)
                       histos->fill2DHist(dy,y_aver,ss.str().c_str(),"","dy, cm","Yloc, cm","COLZ",25,0.0,0.25,75,-150.0,150.0,1.0,"Test");
	             if(statrng==31 || statrng==32 || statrng==41 || statrng==42)
		       histos->fill2DHist(dy,y_aver,ss.str().c_str(),"","dy, cm","Yloc, cm","COLZ",25,-0.25,0.0,75,-150.0,150.0,1.0,"Test");
		 } // end of if(nhit==6
		 } // end of if(flag_test)
	       } // end of if(nhit==(Int_t)nlayers)
	     } // end of if(m_nsegments_chamber[key_chmb]==1)
	   } // end of if j<10
	 } // end of for(UInt_t j=0;j<(*fmuons_cscSegmentRecord_nRecHits)[i]...
         if(flag_test) histos->fill1DHist((Float_t)segmindmx,"segmindmx_per_event","","Max. segment index in nonempty track per event","Entires",4,10,0.0,10.0,1.0,"Test");
       } // end of if (*fmuons_cscSegmentRecord_nRecHits)[i].size() > 0
     } // end of for(UInt_t i=0;i<fmuons_cscSegmentRecord_nRecHits->size();i++)
     if(flag_test) histos->fill1DHist((Float_t)trackneindmx,"trackneindmx_per_event","","Max. nonempty track index per event","Entires",4,30,0.0,30.0,1.0,"Test");

     if(flag_test) if(m_cscSegments_single_trk_recHitRecord.size() > 0) 
       histos->fill1DHist((Float_t)m_cscSegments_single_trk_recHitRecord.size(),"single_segm_rechits_trk_per_event","","Track single segment hits per event","Entries",4,100,0.0,100.0,1.0,"Test");
     if(flag_test) if(m_muon_segm.size() > 0) histos->fill1DHist((Float_t)m_muon_segm.size(),"single_segm_tracks_per_event","","# of single track_segments per event","Entires",4,20,0.0,20.0,1.0,"Test");
     } // end of if single muon track per event (trackne==1)
     } // end of    if(m_Single_cscSegments_recHitRecordX.size() > 0) 
}

/* *******************  GetRecHitsSumQ ********************************* */

void AnalysisGasGain::GetRecHitsSumQ(HistMan* histos) {

  
  std::map <Int_t, Double_t> m_mindx,m_mindy;
  m_mindx.clear(); m_mindy.clear();
  
     if(m_cscSegments_single_trk_recHitRecord.size() > 0) {
       for(Int_t irechit=0;irechit<frecHits2D_nRecHits2D;irechit++) {
          // look at hits with SumQ>0
          if(frecHits2D_SumQ[irechit] > 0.0) {
            Int_t endcap=frecHits2D_ID_endcap[irechit];
            Int_t station=frecHits2D_ID_station[irechit];
            Int_t ring=frecHits2D_ID_ring[irechit];
            Int_t chamber=frecHits2D_ID_chamber[irechit];
            Int_t layer=frecHits2D_ID_layer[irechit];
            Double_t xloc=frecHits2D_localX[irechit];
            Double_t yloc=frecHits2D_localY[irechit];
            Double_t sumq=frecHits2D_SumQ[irechit];

            Int_t key_layer=GetKeyLayer(endcap,station,ring,chamber,layer);
            if(m_cscSegments_single_trk_recHitRecord.find(key_layer)!=m_cscSegments_single_trk_recHitRecord.end()) {
              Double_t dx=xloc-m_cscSegments_single_trk_recHitRecord[key_layer][0];
              Double_t dy=yloc-m_cscSegments_single_trk_recHitRecord[key_layer][1];
              if(flag_test) histos->fill1DHist(10.0*dx,"xloc_sgmxloc","","xloc-segmentxloc, mm","Entries",4,200,-0.1,0.1,1.0,"Test");
             if(flag_test)  histos->fill1DHist(10.0*dy,"yloc_sgmyloc","","yloc-segmentyloc, mm","Entries",4,200,-0.1,0.1,1.0,"Test");

              if(m_mindx.find(key_layer)==m_mindx.end()) 
		m_mindx[key_layer]=999.0;
              if((fabs(dx) < m_mindx[key_layer]) && (fabs(dx)>0.0001))  
                m_mindx[key_layer]=fabs(dx);
              if(m_mindy.find(key_layer)==m_mindy.end()) 
		m_mindy[key_layer]=999.0;
              if((fabs(dy) < m_mindy[key_layer]) && (fabs(dy)>0.0001))  
                m_mindy[key_layer]=fabs(dy);
               
              // identify hits belonging to track segment and assign sumq
              // because only frecHits2D_SumQ has sumq
	      if(fabs(dx) < 0.0001 && fabs(dy) < 0.0001)
               m_cscSegments_single_trk_recHitRecord[key_layer][2]=sumq;
  
	    } // end of if(m_cscSegments_single_trk_recHitRecord.find...
	  } // end of  if((frecHits2D_SumQ[irechit] > 0.0)
       } // end of  for(Int_t irechit=0;irechit<frecHits2D_nRecHits2D;

       if(flag_test) {
         for(map<Int_t,Double_t>::iterator It=m_mindx.begin(); It!=m_mindx.end(); It++) {
	    Float_t dx=(Float_t)(*It).second;
            histos->fill1DHist(10.0*dx,"mindx","","min dxloc, mm","Entries",4,200,0.0,0.2,1.0,"Test");
	 }
         for(map<Int_t,Double_t>::iterator It=m_mindy.begin(); It!=m_mindy.end(); It++) {
	    Float_t dy=(Float_t)(*It).second;
            histos->fill1DHist(dy,"mindy","","min dyloc, cm","Entries",4,200,0.0,2.0,1.0,"Test");
	 }
       }   // end of if(flag_test)

        for(map<Int_t, std::vector <Double_t> >::iterator It=m_cscSegments_single_trk_recHitRecord.begin(); It!=m_cscSegments_single_trk_recHitRecord.end(); It++) {
       if((*It).second[2] > 0.0) {
         Int_t key_layer=(*It).first;
     
         if(m_cscSegments_single_trk_recHitRecord_final.find(key_layer)==
	    m_cscSegments_single_trk_recHitRecord_final.end()) {

           m_cscSegments_single_trk_recHitRecord_final[key_layer]=
	   m_cscSegments_single_trk_recHitRecord[key_layer];
	 }
       }
	} // end of  for(map<Int_t, std::vector <Double_t> >::iterator It=m_cscSegments_single_trk_recHitRecord.begin()

        Float_t df=(Float_t)m_cscSegments_single_trk_recHitRecord.size() - 
	           (Float_t)m_cscSegments_single_trk_recHitRecord_final.size();
	      
        if(flag_test) histos->fill1DHist(df,"diff_map_sizes","","Difference in two map sizes","Entries",4,10,0.0,10.0,1.0,"Test");
        if(df !=0.0) {
	  cout<<"Warning, different map sizes "<<m_cscSegments_single_trk_recHitRecord.size()<<" "<<m_cscSegments_single_trk_recHitRecord_final.size()<<" "<<fEvent<<endl;
	}
        if(flag_test) histos->fill1DHist((Float_t)m_cscSegments_single_trk_recHitRecord_final.size(),"final_used_rechits_per_event","","Number of used rechits per event","Entries",4,100,0.0,100.0,1.0,"Test");

        // do we have rechits from ME1/1a (e.g. ME1/4) and ME1/1b (e.g. ME1/1)
        // in ME11 chamber for single segment per chamber in single track per 
        // event 

	std::map<Int_t, Int_t> m_me11_me14, m_me11,m_me14;
        m_me11_me14.clear();  m_me11.clear(); m_me14.clear();
        for(map<Int_t, std::vector <Double_t> >::iterator It=m_cscSegments_single_trk_recHitRecord_final.begin(); It!=m_cscSegments_single_trk_recHitRecord_final.end(); It++) {
	   Int_t key_layer=(*It).first;
           Int_t key_chmb=key_layer/10;
           Int_t key_ring=key_layer/1000;
           Int_t key_station=key_layer/10000;

           Int_t endcap=key_layer/100000;
           Int_t station=key_station-10*endcap;
           Int_t ring=key_ring-10*key_station;       
           Int_t chamber=key_chmb-100*key_ring;
           Int_t layer=key_layer-10*key_chmb;

           Int_t key_test=GetKeyLayer(endcap,station,ring,chamber,layer);
           if(key_test != key_layer)cout<<"GetRecHitsSumQ Error "<<key_test<<" "<<key_layer<<endl;
           if(key_test == key_layer) {   
	     Int_t key_endcap_chmb=endcap*100+chamber;
	     if(station==1 && ring==1) {
               if(m_me11.find(key_endcap_chmb)==m_me11.end()) { 
                 m_me11[key_endcap_chmb]=0;
               m_me11_me14[key_endcap_chmb]=m_me11_me14[key_endcap_chmb]+1;
	       }
	     }  // end of  if(station==1 && ring==1)
             if(station==1 && ring==4) {
               if(m_me14.find(key_endcap_chmb)==m_me14.end()) {
                 m_me14[key_endcap_chmb]=0;
		 m_me11_me14[key_endcap_chmb]=m_me11_me14[key_endcap_chmb]+2;
	       }	       
	     } // end of  if(station==1 && ring==4)
	   }  // end of  if(key_test == key_layer)
	}    // end of for(map<Int_t, std::vector <Double_t> >::iterator It=m_cscSegments_single_trk_recHitRecord_final.begin()

        if(flag_test) for(map<Int_t, Int_t>::iterator It=m_me11_me14.begin(); It!=m_me11_me14.end(); It++)  histos->fill1DHist((Float_t)(*It).second,"m_me11_me14","","m_me11_me14","Entries",4,5,0.0,5.0,1.0,"Test");
        
     } // end of if(m_cscSegments_single_trk_recHitRecord.size() > 0)
}

/* *******************  FillSumQHists ********************************** */

void AnalysisGasGain::FillSumQHists(HistMan* histos) {

ostringstream ss;
std::map<Int_t, Int_t> m_nRecHitlayer_ME11,m_chmb_trksgm,m_chmb_trksgm_eff;
m_nRecHitlayer_ME11.clear();
m_chmb_trksgm.clear();
m_chmb_trksgm_eff.clear();

m_csc_layer_hvsegm_Xloc.clear();
m_csc_layer_hvsegm_Yloc.clear();
m_csc_layer_hvsegm_SumQ.clear();
m_csc_layer_nhitsel.clear();

       for(map<Int_t, std::vector <Double_t> >::iterator It=m_cscSegments_single_trk_recHitRecord_final.begin(); It!=m_cscSegments_single_trk_recHitRecord_final.end(); ++It) {

          Int_t key_layer=(*It).first;
          Int_t endcap=key_layer/100000;
          Int_t srcl=key_layer-100000*endcap; Int_t station=srcl/10000;
          Int_t rcl=srcl-10000*station;       Int_t ring=rcl/1000;
          Int_t cl=rcl-1000*ring; Int_t chamber=cl/10;
          Int_t layer=cl-10*chamber;

          Int_t key_layer_test=GetKeyLayer(endcap,station,ring,chamber,layer);
          if(key_layer!=key_layer_test) cout<<"Error key_layer key_layer_test "<<key_layer<<" "<<key_layer_test<<endl;

          // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
          // Treat ME11 and ME14 together, e.g one and the same hist for ME1/1a
          // and ME1/1b parts of the same layer of the same CSC.
          // It is justified if no data were lost from readout electronics.
          if(ring==4) ring=1; 
          // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

          Int_t stationring=10*station+ring;

          // find HV segment
	  Float_t yloc=(Float_t)(*It).second[1];
          Int_t hvsgm=doHVsegment(yloc,station,ring,layer);
          if(flag_hists) histos->fill1DHist((float)hvsgm,"HV_segment","","HV segment #","Entries",4,6,0.0,6.0,1.0,"Hists");
     
          if(hvsgm > 0) { // skip rechits having no HV segment

            // Make atm. pressure gas gain correction. No correction if 
            // map m_atmpres is empty (no data on atm pressure)
            Float_t sumq_nc=(Float_t)(*It).second[2];
            Int_t hour=(Int_t)(ftimeSecond/3600);
            Float_t sumq=GetSumQAtmCorr(histos,station,ring,sumq_nc,hour);

            ss.str("");
            ss<<"SumQ_";
            ss<<endcap<<station<<ring;
            if(chamber<10) ss<<0;
            ss<<chamber<<layer;
            if(stationring != 11) ss<<hvsgm;

            if(flag_histssegm) histos->fill1DHist(sumq,ss.str().c_str(),ss.str().c_str(),"recHit SumQ","Entries",4,4000,0.0,4000.0,1.0,"HistsSegm"); 

	    if(flag_hists) {
              ss.str("");
              ss<<"SumQ_";
              ss<<station<<ring;
              histos->fill1DHist(sumq,ss.str().c_str(),ss.str().c_str(),"recHit SumQ","Entries",4,4000,0.0,4000.0,1.0,"Hists");

              histos->fill1DHist(sumq,"SumQ","","recHit SumQ","Entries",4,4000,0.0,4000.0,1.0,"Hists");
              if(stationring != 11) 
                histos->fill1DHist(sumq,"SumQ_nonME11","","recHit SumQ","Entries",4,4000,0.0,4000.0,1.0,"Hists"); 

              ss.str(""); ss<<"Yloc_ME"<<station<<ring;
              if(stationring != 11) histos->fill1DHist(yloc,ss.str().c_str(),ss.str().c_str(),"recHitYloc, cm","Entries",4,150,-150.0,150.0,1.0,"Hists");
              if(stationring == 11) histos->fill1DHist(yloc,ss.str().c_str(),ss.str().c_str(),"recHitYloc, cm","Entries",4,200,-100.0,100.0,1.0,"Hists");

	      // # of hits per layer in selected track segments for nonME11
              if(m_nRecHitlayer.find(key_layer) != m_nRecHitlayer.end() && 
                stationring != 11) {
	        Int_t nhits_sel=m_nRecHitlayer[key_layer];
                histos->fill1DHist((Float_t)nhits_sel,"nhits_sel_nonME11","","# of hits per layer in selected track segments","Entries",4,10,0.0,10.0,1.0,"Hists");
	      }
	    } // end of if(flag_hists)

            // # of hits per layer in selected track segments for ME11
            if(m_nRecHitlayer.find(key_layer) != m_nRecHitlayer.end() && 
               stationring == 11) {
               Int_t nhits_sel=m_nRecHitlayer[key_layer];
               Int_t key_layer_ME11=GetKeyLayer(endcap,station,ring,chamber,layer);
               if(m_nRecHitlayer_ME11.find(key_layer_ME11)==m_nRecHitlayer_ME11.end())
		 m_nRecHitlayer_ME11[key_layer_ME11]=0;
	       m_nRecHitlayer_ME11[key_layer_ME11]=m_nRecHitlayer_ME11[key_layer_ME11]+nhits_sel;   
	    }
            // Remember that ring=1 if it was 4
            Int_t key_chmb=GetKeyLayer(endcap,station,ring,chamber,layer)/10;
            if(m_chmb_trksgm.find(key_chmb) == m_chmb_trksgm.end())
	      m_chmb_trksgm[key_chmb]=0;
            m_chmb_trksgm[key_chmb]=m_chmb_trksgm[key_chmb]+1;      

            //  store X local for given HV segment in given layer of given CSC
            // to use for linear fit and resolution;
            //  remember that ring=1 if it was 4 
            if(stationring==11) hvsgm=1; // for ME11, one HV segment per layer
            Int_t  key_hvsgm=100*key_chmb+10*layer+hvsgm;
            Int_t  key_layer_single=GetKeyLayer(endcap,station,ring,chamber,layer); // to count # of used hits per layer, must be 1.
            if(m_csc_layer_hvsegm_Xloc.find(key_hvsgm)==m_csc_layer_hvsegm_Xloc.end()) {
              m_csc_layer_hvsegm_Xloc[key_hvsgm]=(*It).second[0];  // X local
              m_csc_layer_hvsegm_Yloc[key_hvsgm]=(*It).second[1];  // Y local
              m_csc_layer_hvsegm_SumQ[key_hvsgm]=(*It).second[2];  // SumQ
	    }
            if(m_csc_layer_nhitsel.find(key_layer_single)==m_csc_layer_nhitsel.end())      m_csc_layer_nhitsel[key_layer_single]=0;
            m_csc_layer_nhitsel[key_layer_single]= m_csc_layer_nhitsel[key_layer_single]+1;
         
	  } // end if (hvsgm > 0)
       } // end of   for(map<Int_t, std::vector <Double_t> >::iterator It=m_cscSegments_single_trk_recHitRecord_final.begin()

        if(flag_hists) for(map<Int_t, Int_t>::iterator It=m_nRecHitlayer_ME11.begin(); It!=m_nRecHitlayer_ME11.end(); ++It) {
	   Int_t nhits_sel=(*It).second;
           histos->fill1DHist((Float_t)nhits_sel,"nhits_sel_ME11","","# of hits per layer in selected track segments","Entries",4,10,0.0,10.0,1.0,"Hists");
	}
        // Fill 2D hist of ME vs CSC to sum used for gas gain segments in CSC
         if(flag_test) histos->fill1DHist((Float_t)m_chmb_trksgm.size(),"used_trksegm_ev","","# of used track segments per event","Entries",4,20,0.0,20.0,1.0,"Test");
        if(m_chmb_trksgm.size() > 0) {
          for(map<Int_t, Int_t>::iterator It=m_chmb_trksgm.begin(); It!=m_chmb_trksgm.end(); ++It) {
	     Int_t key_chmb=(*It).first;
             Int_t key_encpstatring=key_chmb/100;
             if(m_ordencpstatring.find(key_encpstatring) ==m_ordencpstatring.end()) cout<<"FillSumQHists error "<<key_chmb<<" "<<key_encpstatring<<endl; 
             if(m_ordencpstatring.find(key_encpstatring) != m_ordencpstatring.end()) {
               Float_t x=key_chmb-100*key_encpstatring;
               Float_t y=m_ordencpstatring[key_encpstatring];
               if(flag_test) histos->fill2DHist(x,y,"used_trksegm_csc","","CSC","ME-+","COLZ",36,1.0,37.0,18,1.0,19.0,1.0,"Test");
	     }
             Float_t nlay=(*It).second;
             if(flag_test) histos->fill1DHist(nlay,"used_layers_csc_ev","","# of used layers per csc in selected track segments","Entries",4,10,0.0,10.0,1.0,"Test");
          } // end of for(map<Int_t, Int_t>::iterator It=m_chmb_trksgm.begin()
	} // end of m_chmb_trksgm.size() > 0
}

Int_t  AnalysisGasGain::SameStripBin(std::vector <Float_t> xstrip) {

  std::map<Int_t, Int_t> m_SameStripBin;
  m_SameStripBin.clear();

  Int_t flag=0;
  Int_t binsel=0;
  for(Int_t i=0;i<(Int_t)xstrip.size(); i++) {
     Float_t xs=xstrip[i];
     Int_t bin=0;
     if(xs<-0.4) bin=1;
     if(xs>=0.4)  bin=10;
     if(xs>=-0.4 && xs<0.4) bin=(xs+0.4)/0.1+2;
     if(bin>0 && bin<=10) {
       if(m_SameStripBin.find(bin)==m_SameStripBin.end())
          m_SameStripBin[bin]=0;
       m_SameStripBin[bin]=m_SameStripBin[bin]+1;
     }
     else  cout<<"bin error "<<bin<<endl;
  }
  if(m_SameStripBin.size()==1) {
    std::map<Int_t,Int_t>::iterator It=m_SameStripBin.begin();
    if((*It).first<=5) binsel=6-(*It).first;
    if((*It).first>5) binsel=(*It).first-5;
    if(binsel>0 && binsel<6 && (*It).second == (Int_t)xstrip.size()) flag=1;
    else cout<<"binsel error "<<binsel<<endl;
  }
  if(flag==1) flag=binsel;
  return flag;
}

void AnalysisGasGain::CscResolution(HistMan* histos) {

  Int_t flag_xloc_xstrip=1; // 1-fit using X within strip coordinate
                            // 2-fit using X local coordinate
  ostringstream ss,sx;
  std::map<Int_t,std::vector <Double_t> > m_CscXlocToFit;
  std::map<Int_t,std::vector <Double_t> > m_CscYlocToFit;
  std::map<Int_t,std::vector <Double_t> > m_CscSumQ;
  std::map<Int_t,std::vector <Int_t> >    m_CSCLayerHVsgm;
  std::map<Int_t, Int_t>                  m_SameStrip,m_SameStripBin;
  std::map<Int_t, Int_t>                  m_ylocbinout;
  std::map<Int_t, Float_t>                m_xlocflat;
  std::map<Int_t,std::vector <Double_t> > m_StripCoord;
  std::map<Int_t,std::vector <Double_t> > m_StripWidth;
  std::map<Int_t,std::vector <Int_t> >    m_StripNhits;
  std::map<Int_t,std::vector <Int_t> >    m_StripNear;

  Int_t me[9]={11,12,13,21,22,31,32,41,42}; //ME station/ring
  Int_t mehvsgm[9]={1,3,3,3,5,3,5,3,5}; // # of HV segments
  Float_t xlocflat[31]={100.0,200.0,250.0,300.0,
			      250.0,300.0,350.0,
			      200.0,350.0,400.0,
			      300.0,300.0,400.0,500.0,500.0,
                              300.0,350.0,400.0,
			      300.0,350.0,400.0,450.0,500.0,
			      300.0,350.0,400.0,
			      300.0,350.0,400.0,450.0,500.0};
  // # of bins, xlow and xhigh for X local distributions, mm
  Int_t nbinxloc[9]={10001,16801,18801,26001,26001,26001,26001,26001,26001};
  Float_t xlowxloc[9]={-250.025,-420.025,-470.025,-650.025,-650.025,-650.025,-650.025,-650.025,-650.025};
  Float_t xhighxloc[9]={250.025,420.025,470.025,650.025,650.025,650.025,650.025,650.025,650.025};
  // Z-loc coordinates of the CSC layers for fit, mm
  Float_t z_loc[6]={25.40,  50.80,  76.20, 101.60, 127.00, 152.40};
  // The station/ring/HV segments/Yloc bin # to be excluded from resolution
  // analysis due different from average gas gain, is stored in m_ylocbinout
  Int_t ylocbinexclude[15]={1111,1216,1236,1312,2117,2136,2218,2246,2256,
                            3115,3136,3218,3246,3256,4115};

  m_CscXlocToFit.clear();
  m_CscYlocToFit.clear();
  m_CSCLayerHVsgm.clear();
  m_CscSumQ.clear();
  m_xlocflat.clear();
  m_ylocbinout.clear();
  m_StripCoord.clear();
  m_StripWidth.clear();
  m_StripNhits.clear();
  m_StripNear.clear();

  Int_t ind=0;
  for(Int_t i=0;i<9;i++) 
    for(Int_t j=0;j<mehvsgm[i]; j++) {
       Int_t key=10*me[i]+(j+1);
       m_xlocflat[key]=xlocflat[ind];
       ind++;
    }

  for(Int_t i=0;i<15;i++) {
     Int_t key=ylocbinexclude[i];
     m_ylocbinout[key]=0;
  }
  // Store X local, Y local and HV segments to maps
  Int_t idstation[4]={0};
  for(std::map<Int_t,Double_t>::iterator It=m_csc_layer_hvsegm_Xloc.begin(); It!= m_csc_layer_hvsegm_Xloc.end();++It) {
    Int_t key_hvsgm=(*It).first;
    Int_t key_layer=key_hvsgm/10;
    Int_t key_chmb=key_layer/10;
    Int_t hvsgm=key_hvsgm-key_layer*10;
    Int_t layer=key_layer-key_chmb*10;
    Int_t key_chmb_hvsgm=10*key_chmb+hvsgm;
    Int_t estat=(Int_t)(key_chmb/1000);
    Int_t endcup=(Int_t)(key_chmb/10000);
    Int_t station=estat-endcup*10;
 
    Int_t flag_error=0;
    
    if(m_csc_layer_nhitsel.find(key_layer)== m_csc_layer_nhitsel.end()) {
      flag_error=flag_error+1;
      cout<<"AnalysisGasGain::CscResolution error, no such key_layer in m_csc_layer_nhitsel "<<key_layer<<endl;
    }
    if(m_csc_layer_nhitsel.find(key_layer)!= m_csc_layer_nhitsel.end() &&
       m_csc_layer_nhitsel[key_layer]!=1) {
      flag_error=flag_error+2;
      cout<<"AnalysisGasGain::CscResolution error, # of hits in layer !=1 "<<
	key_layer<<" "<< m_csc_layer_nhitsel[key_layer]<<endl;
    }
    if(flag_error==0) {
      if(m_CscXlocToFit.find(key_chmb_hvsgm)==m_CscXlocToFit.end()) {
        m_CscXlocToFit[key_chmb_hvsgm]=dinit6;
        m_CscYlocToFit[key_chmb_hvsgm]=dinit6;
        m_CSCLayerHVsgm[key_chmb_hvsgm]=izero6;
        m_CscSumQ[key_chmb_hvsgm]=dinit6;
        idstation[station-1]=idstation[station-1]+1;
      }
      // Store X local, Y local and HV segment # and SumQ
      m_CscXlocToFit[key_chmb_hvsgm][layer-1]=(*It).second;
     m_CscYlocToFit[key_chmb_hvsgm][layer-1]=m_csc_layer_hvsegm_Yloc[key_hvsgm];
      m_CscSumQ[key_chmb_hvsgm][layer-1]=m_csc_layer_hvsegm_SumQ[key_hvsgm];
      m_CSCLayerHVsgm[key_chmb_hvsgm][layer-1]=hvsgm;
    }
  }  // end of for(std::map<Int_t,Double_t>::iterator It=m_csc_layer_hvsegm_Xloc.begin()

  // Fill map for hit coordinate within strip and strip width
  for(std::map<Int_t,std::vector <Double_t> > ::iterator It=m_CscXlocToFit.begin(); It!=m_CscXlocToFit.end();++It) {
   Int_t key_chmb_hvsgm=(*It).first;  
   Int_t endcap=key_chmb_hvsgm/100000;
   Int_t station=key_chmb_hvsgm/10000-endcap*10;
   Int_t ring=key_chmb_hvsgm/1000-(endcap*100+station*10);
   Int_t chamber=key_chmb_hvsgm/10-(endcap*10000+station*1000+ring*100);
   if(m_StripCoord.find(key_chmb_hvsgm)==m_StripCoord.end()) {
     m_StripCoord[key_chmb_hvsgm]=dinit6;
     m_StripWidth[key_chmb_hvsgm]=dinit6;
     m_StripNhits[key_chmb_hvsgm]=izero6;
     m_StripNear[key_chmb_hvsgm]=izero6;

     for(Int_t ilayer=0;ilayer<6;ilayer++) {
        if((*It).second[ilayer]> -999.0) {
          Int_t layer=ilayer+1;
          for(Int_t irechit=0;irechit<frecHits2D_nRecHits2D;irechit++) {
             Float_t x_strip=frecHits2D_positionWithinStrip[irechit];
             if(It==m_CscXlocToFit.begin()) histos->fill1DHist(x_strip,"X_strip_before","","X strip","Entries",4,120,-0.6,0.6,1.0,"");
	     // checking for strips to be excluded (have X strip=0.0 )
             Int_t flaghit=0;
             Int_t keyhit=100*(10*frecHits2D_ID_station[irechit] + 
	                   frecHits2D_ID_ring[irechit])          +
	                   frecHits2D_nearestStrip[irechit];
             if(m_strip_zero.find(keyhit) != m_strip_zero.end()) flaghit=1;
             // accept strip if flaghit=0
             if(flaghit==0) {
             Int_t ringhit=frecHits2D_ID_ring[irechit];
             if(ringhit==4) ringhit=1;
             Double_t xloc=frecHits2D_localX[irechit];
             Double_t yloc=frecHits2D_localY[irechit];
             Double_t diffx=xloc-(*It).second[ilayer];
             Double_t diffy=yloc-m_CscYlocToFit[key_chmb_hvsgm][ilayer];
             if(endcap==frecHits2D_ID_endcap[irechit]    &&
                station==frecHits2D_ID_station[irechit]   &&
                ring==ringhit                             && 
                chamber==frecHits2D_ID_chamber[irechit]   &&
                layer==frecHits2D_ID_layer[irechit]       &&
	        fabs(diffx)<0.0001 && fabs(diffy)<0.0001) {
                m_StripCoord[key_chmb_hvsgm][ilayer]=frecHits2D_positionWithinStrip[irechit];
                if(x_strip==0.0) cout<<"x_strip==0.0 "<<key_chmb_hvsgm<<" "<<ilayer+1<<endl;
                m_StripWidth[key_chmb_hvsgm][ilayer]=frecHits2D_stripWidthAtHit[irechit];
                m_StripNear[key_chmb_hvsgm][ilayer]=frecHits2D_nearestStrip[irechit];
                m_StripNhits[key_chmb_hvsgm][ilayer]=m_StripNhits[key_chmb_hvsgm][ilayer] + 1;
	     } // end of if  if(endcap==
	     } // end of if flaghit==0
	  } //end of for(Int_t irechit=0;
	}   // end of if((*It).second[i]> -999.0)
     } // end of for(Int_t ilayer=0
   } // end of if(m_StripCoord.find(key_chmb_hvsgm)==
  } // end of  for(std::map<Int_t,std::vector <Double_t> > ::iterator It=m_CscXlocToFit.begin
   
   for(std::map<Int_t,std::vector <Int_t> > ::iterator It= m_StripNhits.begin(); It!=m_StripNhits.end();++It) {
     Int_t keyc=(*It).first;
     for(Int_t i=0;i<6;i++) if((*It).second[i] > 1) cout<<"Resolution: Error  m_StripNhits[key][i] > 1 "<<fEvent<<" "<<keyc<<" "<<i+1<<" "<<(*It).second[i]<<endl;
   }
  
  // mark stations as bit and fill hist with result
  Int_t bit=0;
  Int_t cnt=1;
  for (Int_t i=0;i<4;i++) {
    if(idstation[i] > 0) bit=bit+cnt; cnt=cnt*2;
  } 
  histos->fill1DHist((Float_t)bit,"station_bit","","Station bit (1 - ME1, 2 - ME2, 3 - ME3, 4 - ME4)","Entries",4,16,0.0,16.0,1.0,"");

  //if(bit!=1 && bit!=2 && bit!=4 && bit!=8) { //skip single segment tracks !!!!
  //if(bit==15) { // select tracks having segments in all 4 stations
  if(bit > 0) { // at least one track segment in the track
  Int_t np;
  Float_t z[6],x[6],er[6],ft[6],chi2[6],y[6],sumq[6],xloc[6],yloc[6];
  Float_t zcand[6],xcand[6],ercand[6],ycand[6],sumqcand[6];
  Float_t cz[6],cx[6],cer[6]; 
  Float_t a1,a2, da1,da2,da12,chi2t;
  Float_t resid;

  for(std::map<Int_t,std::vector <Double_t> > ::iterator It=m_CscXlocToFit.begin(); It!=m_CscXlocToFit.end();++It) {
    Int_t key_chmb_hvsgm=(*It).first;
    Int_t sgm=key_chmb_hvsgm-10*(key_chmb_hvsgm/10);
    Int_t key_chmb=key_chmb_hvsgm/10;
    Int_t statring=key_chmb_hvsgm/1000-100*(key_chmb_hvsgm/100000);

     if(m_StripCoord.find(key_chmb_hvsgm) != m_StripCoord.end()) {
      for(Int_t i=0;i<6;i++) {
	Float_t x_strip=m_StripCoord[key_chmb_hvsgm][i];
        histos->fill1DHist(x_strip,"X_strip_after","","X strip","Entries",4,120,-0.6,0.6,1.0,"");
      }
     }

    Int_t nlayers=0;
    for(Int_t i=0;i<6;i++) if((*It).second[i]>-999.0) nlayers++;
   
    np=0;
    if(nlayers==6) { 
      Int_t key=10*statring+sgm;
      if(m_xlocflat.find(key)==m_xlocflat.end()) 
        cout<<"Error, no m_xlocflat for key "<<key<<endl;
      if(m_xlocflat.find(key)!=m_xlocflat.end()) {
        Float_t xloclimit=m_xlocflat[key];

        for(Int_t i=0;i<6;i++) {
           Float_t xc=10.0*(*It).second[i];  // X local, cm->mm
           Float_t xs=m_StripCoord[key_chmb_hvsgm][i];
           Float_t xsw=m_StripWidth[key_chmb_hvsgm][i];

	   if(fabs(xc)<xloclimit && fabs(xs)<0.6) {
	     zcand[np]=z_loc[i];   // using real Z local of layers
             if(flag_xloc_xstrip==1) 
               xcand[np]=xs*xsw*10.0;  // X coordinate in strip, mm
             if(flag_xloc_xstrip==2)
               xcand[np]=xc;           // X local coordinate, mm
             ercand[np]=0.200;             // error for fit, mm
             ycand[np]=m_CscYlocToFit[key_chmb_hvsgm][i];
             sumqcand[np]=m_CscSumQ[key_chmb_hvsgm][i];
             if(sumqcand[np]<=0.0) cout<<"Error, sumq[npfit]<=0.0 "<< sumqcand[np] <<" "<<np+1<<" "<<key_chmb_hvsgm<<endl;
             np++;
	   }
	} // end of for(Int_t i=0;i<6;i++)
      } // end of if(m_xlocflat.find(key)!=m_xlocflat.end())
    } // end of  if(nlayers==6) 

      Int_t npfit=0;
      if(np==6) {
      //
      // get bin # for Y local, check for Yloc to be excluded
      //
      Int_t statring_sgm=statring*10+sgm;
      if(m_csc_hvsgm_bound.find(statring_sgm) != m_csc_hvsgm_bound.end()) {
        for(int i=0;i<np;i++) {
	   if(ycand[i]>m_csc_hvsgm_bound[statring_sgm][0] &&
	     ycand[i]<m_csc_hvsgm_bound[statring_sgm][1]) {
	     Int_t biny=(ycand[i]-m_csc_hvsgm_bound[statring_sgm][0])/m_csc_hvsgm_binw[statring_sgm] + 1;
             if(biny>0 && biny<10) {
               Int_t statring_sgm_bin=10*statring_sgm+biny;
               if(m_ylocbinout.find(statring_sgm_bin)==m_ylocbinout.end()) {
                 x[npfit]=xcand[i];
		 z[npfit]=zcand[i];
                 er[npfit]=ercand[i];
                 y[npfit]=ycand[i];
                 sumq[npfit]=sumqcand[i];
                 npfit++;
	       } // end of if(m_ylocbinout.find(statring_sgm_bin)==
	     } // end of  if(biny>0
	   } // end of  if(ycand[i]>m_csc_hvsgm_bound[statring_sgm][0] &&
	} // end of for(int i=0;i<np;i++)
      } // end of if(m_csc_hvsgm_bound.find(statring_sgm) !=
      
      if(npfit==6) {

        for(Int_t i=0;i<6;i++) {
	  xloc[i]=m_CscXlocToFit[key_chmb_hvsgm][i];
          yloc[i]=m_CscYlocToFit[key_chmb_hvsgm][i];
	}

	Int_t np6=6,np3=3,flag_fit=0;
        Float_t z6[6],x6[6],er6[6],xloc6[6],yloc6[6];
        Float_t z3[3],x3[3],er3[3],xloc3[3],yloc3[3];

        //
	// fitting layers 1,2,3,4,5,6 for ME11 as (6,6) fit
        //
        // Selecting hits having one and the same strip in all 6 layers of ME11
        if(statring==11) {
        m_SameStrip.clear();
        for(Int_t i=0;i<6;i++) {
	   Int_t strip=m_StripNear[key_chmb_hvsgm][i];
           if(m_SameStrip.find(strip)== m_SameStrip.end()) 
              m_SameStrip[strip]=0; 
	   m_SameStrip[strip]= m_SameStrip[strip]+1;
	}
        if(flag_xloc_xstrip==1) { // if fit X within strip
        ss.str(""); ss<<"ME11_m_SameStrip.size";         
        histos->fill1DHist((Float_t)m_SameStrip.size(),ss.str().c_str(),ss.str().c_str(),"ME11_m_SameStrip.size","Entries",4,7,0.0,7.0,1.0,"");
	}

        flag_fit=0;
        if(flag_xloc_xstrip==1 && m_SameStrip.size()==1) flag_fit=1;
	if(flag_fit==1) {
          for(Int_t i=0;i<6;i++) {
              Float_t x_strip=m_StripCoord[key_chmb_hvsgm][i];
              histos->fill1DHist(x_strip,"X_strip_the_same_ME11","","X strip","Entries",4,120,-0.6,0.6,1.0,"");
	  }
	}

        // fitting X local
        if(flag_xloc_xstrip==2)  flag_fit=1;

        if(flag_fit==1) {
       
	for(Int_t i=0;i<6;i++) {
	  z6[i]=z[i];x6[i]=x[i];er6[i]=er[i];
          xloc6[i]=xloc[i];yloc6[i]=yloc[i];
	}

        // (6,6) fit for ME11
        linfit(np6,z6,x6,er6,a1,a2,ft,da1,da2,da12,chi2,chi2t); 
        // check that fitted track belongs to one and the same x strip bin 

        std::vector <Float_t> xstrip;
	xstrip.clear();
        for(Int_t i=0;i<6;i++) {
           Float_t xstripcoor=(a1+a2*z6[i])/(m_StripWidth[key_chmb_hvsgm][i]*10.0);
	   xstrip.push_back(xstripcoor);
	}
        Int_t bin_sel=SameStripBin(xstrip);
        if(bin_sel > 0) {
           // Get residuals for x6[i]
          for(Int_t i=0;i<6;i++) {  
             resid=x6[i]-(a1+a2*z6[i]);   // residual (mm) in point i
             Int_t layer=i+1;
             ss.str(""); 
             ss<<"Resid_6_6_"<<key_chmb<<layer<<"_"<<sgm<<"_"<<bin_sel;
             histos->fill1DHist(resid,ss.str().c_str(),ss.str().c_str(),"Residual, mm","Entries",4,1000,-5.0,5.0,1.0,"Resid");

	     ss.str("");
             ss<<"Resid_6_6_ME"<<statring<<"_"<<layer<<"_"<<sgm<<"_"<<bin_sel;
             histos->fill1DHist(resid,ss.str().c_str(),ss.str().c_str(),"Residual, mm","Entries",4,1000,-5.0,5.0,1.0,"");
	  } // end of for(Int_t i=0;i<6;i++)

	} // end of  if(bin_sel>0) 
	} // end of if(flag_fit==1)
	} // end of if statring==11

        //
	// fitting layers 1,3,5 as (3,3) for nonME11
        //
        // Selecting hits having one and the same strip in  3 layers of nonME11
           if(statring != 11) {
             m_SameStrip.clear();
             for(Int_t i=0;i<3;i++) {
	        Int_t k=2*i;
                Int_t strip=m_StripNear[key_chmb_hvsgm][k];
                if(m_SameStrip.find(strip)== m_SameStrip.end()) 
                  m_SameStrip[strip]=0; 
	        m_SameStrip[strip]= m_SameStrip[strip]+1;
	     }

             flag_fit=0;
             if(flag_xloc_xstrip==1 && m_SameStrip.size()==1) flag_fit=1;
             if(flag_fit==1) {
               for(Int_t i=0;i<3;i++) {
                  Int_t k=2*i;
                  Float_t x_strip=m_StripCoord[key_chmb_hvsgm][k];
                  histos->fill1DHist(x_strip,"X_strip_the_same_nonME11","","X strip","Entries",4,120,-0.6,0.6,1.0,"");
	       }        
	     } // end of if(flag_fit==1)

             // fitting X local
              if(flag_xloc_xstrip==2)  flag_fit=1;

              if(flag_fit==1) {

                for(Int_t i=0;i<3;i++) {
	           Int_t k=2*i;
                   z3[i]=z[k];  x3[i]=x[k];  er3[i]=er[k];
                   xloc3[i]=xloc[k]; yloc3[i]=yloc[k];
		}

                // fit(3,3)
                linfit(np3,z3,x3,er3,a1,a2,ft,da1,da2,da12,chi2,chi2t); 

                // check that  fitted points belong to one and the same 
                // x strip bin in layers
                std::vector <Float_t> xstrip;
                xstrip.clear();
                for(Int_t i=0;i<3;i++) {
                Int_t k=2*i;   
                Float_t xstripcoor=(a1+a2*z3[i])/(m_StripWidth[key_chmb_hvsgm][k]*10.0);
	        xstrip.push_back(xstripcoor);
		}
                Int_t bin_sel=SameStripBin(xstrip);

                if(bin_sel > 0) {
                  // Get residuals for x3[i] (layers 1,3,5 in nonME11 CSCs)
                  for(Int_t i=0;i<3;i++) {
                  resid=x3[i]-(a1+a2*z3[i]);   // residual (mm) in point i
                  Int_t layer=i*2+1;
                  ss.str(""); 
                  ss<<"Resid_3_3_"<<key_chmb<<layer<<"_"<<sgm<<"_"<<bin_sel;    
                  histos->fill1DHist(resid,ss.str().c_str(),ss.str().c_str(),"Residual, mm","Entries",4,1000,-5.0,5.0,1.0,"Resid");
                  ss.str("");
                  ss<<"Resid_3_3_ME"<<statring<<"_"<<layer<<"_"<<sgm<<"_"<<bin_sel;
                  histos->fill1DHist(resid,ss.str().c_str(),ss.str().c_str(),"Residual, mm","Entries",4,1000,-5.0,5.0,1.0,"");
		  } // end of for(Int_t i=0;i<3
		} // end of if(bin_sel > 0)

	      } // end of if(flag_fit==1) { 
	   }  // end of if(statring != 11) {

	//
        // fitting layers 2,4,6 as (3,3)
        //Selecting hits having one and the same strip in  3 layers of nonME11
	//
           if(statring != 11) {
            m_SameStrip.clear();
            for(Int_t i=0;i<3;i++) {
	      Int_t k=2*i+1;
              Int_t strip=m_StripNear[key_chmb_hvsgm][k];
               if(m_SameStrip.find(strip)== m_SameStrip.end()) 
                 m_SameStrip[strip]=0; 
	       m_SameStrip[strip]= m_SameStrip[strip]+1;
	    }

            flag_fit=0;
            if(flag_xloc_xstrip==1 && m_SameStrip.size()==1) flag_fit=1;
            if(flag_fit==1) {
              for(Int_t i=0;i<3;i++) {
                  Int_t k=2*i+1;
                  Float_t x_strip=m_StripCoord[key_chmb_hvsgm][k];
                  histos->fill1DHist(x_strip,"X_strip_the_same_nonME11","","X strip","Entries",4,120,-0.6,0.6,1.0,"");
	      }
	    } // end of if(flag_fit==1)

            // fitting X local
            if(flag_xloc_xstrip==2)  flag_fit=1;

            if(flag_fit==1) {

            for(Int_t i=0;i<3;i++) {
	      Int_t k=2*i+1;
              z3[i]=z[k];  x3[i]=x[k];  er3[i]=er[k];
              xloc3[i]=xloc[k]; yloc3[i]=yloc[k]; 
	    }

            // fit (3,3)
            linfit(np3,z3,x3,er3,a1,a2,ft,da1,da2,da12,chi2,chi2t);
            // check that  fitted points belong to one and the same 
            //x strip bin in layers                
            std::vector <Float_t> xstrip;
	    xstrip.clear();
            for(Int_t i=0;i<3;i++) {
            Int_t k=2*i+1;
            Float_t xstripcoor=(a1+a2*z3[i])/(m_StripWidth[key_chmb_hvsgm][k]*10.0);
	    xstrip.push_back(xstripcoor);
	    }
            Int_t bin_sel=SameStripBin(xstrip);
            // Get residuals for x3[i] (layers 2,4,6 in nonME11 CSCs)
            if(bin_sel>0) {
              for(Int_t i=0;i<3;i++) {
                 resid=x3[i]-(a1+a2*z3[i]);   // residual (mm) in point i
                 Int_t layer=i*2+2;
                 ss.str(""); 
                 ss<<"Resid_3_3_"<<key_chmb<<layer<<"_"<<sgm<<"_"<<bin_sel; 
                 histos->fill1DHist(resid,ss.str().c_str(),ss.str().c_str(),"Residual, mm","Entries",4,1000,-5.0,5.0,1.0,"Resid");
                 ss.str("");
                 ss<<"Resid_3_3_ME"<<statring<<"_"<<layer<<"_"<<sgm<<"_"<<bin_sel;
                 histos->fill1DHist(resid,ss.str().c_str(),ss.str().c_str(),"Residual, mm","Entries",4,1000,-5.0,5.0,1.0,"");
	      } // end of for(Int_t i=0;i<3
	    } // end of if(bin_sel>0)
	    } // end of  if(flag_fit==1)
	   } // end of if(statring != 11)
      } // end of if npfit==6
      } // end of if np==6
  } // end of for(std::map<Int_t,std::vector <Float_t> > ::iterator It=m_CscXlocToFit
  } // end of if(bit > 0...
}

void AnalysisGasGain::GetEffHits(HistMan* histos) {
 ostringstream ss,sx;

 // Use track segments with hits in 5-6 layers only, having hits 
 // in one and the HV segment
 
 for(UInt_t isgm=0;isgm<fcscSegments_recHitRecord_endcap->size();isgm++) {
    if(isgm<100) { // limit 100 segments per event for key_segment
              
      if((Int_t)(*fcscSegments_recHitRecord_endcap)[isgm].size() > 4) {
 
        Float_t hit_layer_Y[6]={-999.0,-999.0,-999.0,-999.0,-999.0,-999.0};
        Int_t endcap=(Int_t)(*fcscSegments_recHitRecord_endcap)[isgm][0];
        Int_t station=(Int_t)(*fcscSegments_recHitRecord_station)[isgm][0];
        Int_t ring=(Int_t)(*fcscSegments_recHitRecord_ring)[isgm][0];
        Int_t chamber=(Int_t)(*fcscSegments_recHitRecord_chamber)[isgm][0];

        for(UInt_t j=0;j<(*fcscSegments_recHitRecord_endcap)[isgm].size();j++) {
           // here isgm-segment,j-hit
           Int_t layer=(Int_t)(*fcscSegments_recHitRecord_layer)[isgm][j];
           Double_t localX=(*fcscSegments_recHitRecord_localX)[isgm][j];
           Double_t localY=(*fcscSegments_recHitRecord_localY)[isgm][j];

           // *** check hit in segment against hit in frecHits2D_nRecHits2D
	   // *** for hit having  SumQ<0
           Int_t flaghit=0;
 
           for(Int_t irechit=0;irechit<frecHits2D_nRecHits2D;irechit++) {
	      if(endcap==frecHits2D_ID_endcap[irechit]    &&
                 station==frecHits2D_ID_station[irechit]  &&
                 ring==frecHits2D_ID_ring[irechit]        && 
                 chamber==frecHits2D_ID_chamber[irechit]  &&
                 layer==frecHits2D_ID_layer[irechit]) {

                Double_t dx=localX-frecHits2D_localX[irechit];
                Double_t dy=localY-frecHits2D_localY[irechit];
                Double_t SumQ=frecHits2D_SumQ[irechit];
                if(fabs(dx) < 0.0001 && fabs(dy) < 0.0001 && SumQ > 0.0) {
                  flaghit++; 
                  hit_layer_Y[layer-1]=localY;
		}
	      } // end of  if(endcap==frecHits2D_ID_endcap[irechit]
	   } // end of for(Int_t irechit=0;irechit<frecHits2D_nRecHits2D;
           if(flaghit > 1) cout<<"GetEffHits Error, flaghit > 1:  "<<flaghit<<"    "<<endcap<<" "<<station<<" "<<ring<<" "<<chamber<<" "<<layer<<" "<<isgm<<" "<<j<<endl;
	} //end for(UInt_t j=0;j<(*fcscSegments_recHitRecord_endcap)[isgm].size()

        // Select track segments with hits in one and the same HV segments. 
        std::map <Int_t, Int_t>   hvg;
        hvg.clear();
	Int_t hvgsegm_eff=0;
        std::vector <Int_t> layer_hvg;
	layer_hvg.clear();
        for(Int_t i=0;i<6;i++) layer_hvg.push_back(0);

        for(Int_t k=0;k<6;k++) {
	  if(hit_layer_Y[k] > -999.0) {
            Float_t Y=hit_layer_Y[k];
            Int_t layer=k+1;
            Int_t hvsegm=doHVsegment(Y,station,ring,layer);
            if(hvsegm>0) {
               //rewrite  hvsegm for ME11 and ME14 CSCs
              if(station==1 && (ring==1 || ring==4)) hvsegm=1; 
              layer_hvg[k]=hvsegm;
              hvgsegm_eff=hvsegm;
              if(hvg.find(hvsegm)==hvg.end()) hvg[hvsegm]=0;
	      hvg[hvsegm]=hvg[hvsegm]+1;
	    }
	  }
	} // end of  for(Int_t k=0;k<6;k++)

        Int_t nhits_segm_eff=0;
        if((Int_t)hvg.size() == 1) { //track segment has hits in one and the 
                                     //same HV segments
          nhits_segm_eff=hvg[hvgsegm_eff];
	}
	histos->fill1DHist((Float_t)nhits_segm_eff,"nhits_segm_eff","","# of selected hits per segment for eff.","Entries",4,10,0.0,10.0,1.0,"Eff");
        if(nhits_segm_eff > 4) {
          if(ring==4) ring=1; // for ME14
          Int_t key_chamber=GetKeyChamber(endcap,station,ring,chamber);
          if(m_nsegments_chamber_eff.find(key_chamber)==m_nsegments_chamber_eff.end()) m_nsegments_chamber_eff[key_chamber]=0;
	  m_nsegments_chamber_eff[key_chamber]=m_nsegments_chamber_eff[key_chamber]+1;
          // elements of map below are filled for the  first segment but we
          // will use cases when there is only one track segment per chamb. 
          if(m_segments_chamber_hvg_eff.find(key_chamber)==m_segments_chamber_hvg_eff.end()) m_segments_chamber_hvg_eff[key_chamber]=layer_hvg;

	} // end of  if(nhits_segm_eff > 4)
      } // end of if((Int_t)(*fcscSegments_recHitRecord_endcap)[isgm].size()>4)
    } // end of  if(isgm<100)
 } // end of for(UInt_t isgm=0;isgm<fcscSegments_recHitRecord_endcap->size()

 // select chambers with single track segment and check against single 
 // muon track

 for(std::map<Int_t,Int_t>::iterator It=m_nsegments_chamber_eff.begin(); It!= m_nsegments_chamber_eff.end();++It) {
       Int_t nsegm=(*It).second;
       histos->fill1DHist((Float_t)nsegm,"eff_segments_per_chamber","","Number of segments for eff. per chamber","Entries",4,10,0.0,10.0,1.0,"Eff");
 }
  if(m_nsegments_chamber_eff.size()>0) {
    Int_t trackne=0;  // non empty track counter, e.g. track with CSC segments
    Int_t itrk=-1;
    for(UInt_t i=0;i<fmuons_cscSegmentRecord_nRecHits->size();i++) 
      if((*fmuons_cscSegmentRecord_nRecHits)[i].size() > 0) {
         trackne++;
         itrk=i;
      }
    if(trackne == 1) { // require event with only one  muon track
      // cycle on # of track segments, itrk-selected track,j-segment
      for(UInt_t j=0;j<(*fmuons_cscSegmentRecord_nRecHits)[itrk].size();j++) {
	 //  require segment j to have > 4 hits (> 4 layers)
	 if((Int_t)(*fmuons_cscSegmentRecord_nRecHits)[itrk][j] > 4) {
	   Int_t endcap=(Int_t)(*fmuons_cscSegmentRecord_endcap)[itrk][j];
	   Int_t station=(Int_t)(*fmuons_cscSegmentRecord_station)[itrk][j];
	   Int_t ring=(Int_t)(*fmuons_cscSegmentRecord_ring)[itrk][j];
           if(ring==4) ring=1;
	   Int_t chamber=(Int_t)(*fmuons_cscSegmentRecord_chamber)[itrk][j];
           Int_t key_chmb=GetKeyChamber(endcap,station,ring,chamber);
           if((m_nsegments_chamber_eff.find(key_chmb) != m_nsegments_chamber_eff.end()) && m_nsegments_chamber_eff[key_chmb]==1) {
             if(m_segments_chamber_hvg_eff_final.find(key_chmb)==m_segments_chamber_hvg_eff_final.end()) m_segments_chamber_hvg_eff_final[key_chmb]=m_segments_chamber_hvg_eff[key_chmb];
	   }
	 }
      }// end for(UInt_t j=0;j<(*fmuons_cscSegmentRecord_nRecHits)[itrk].size()
      if(m_segments_chamber_hvg_eff_final.size() > 0) {
        histos->fill1DHist((Float_t)m_segments_chamber_hvg_eff_final.size(),"chambers_eff_segments_per_event","","Number of chambers for eff. per event","Entries",4,10,0.0,10.0,1.0,"Eff");

      // fill 2D hists for  # of hits from selected segments and # of selected 
      // segments vs CSC 
       for(std::map<UInt_t,std::vector <Int_t> >::iterator It=m_segments_chamber_hvg_eff_final.begin(); It!=m_segments_chamber_hvg_eff_final.end();++It) {
	 Int_t key_chmb=(*It).first;
         Int_t endcap=key_chmb/10000;
         Int_t station=key_chmb/1000-endcap*10;
         Int_t ring=key_chmb/100-(endcap*100+station*10);
         if(ring==4) cout<<"GetEffHits Error Ring==4 "<< key_chmb <<endl;
         Int_t chamber=key_chmb-(endcap*10000+station*1000+ring*100);
         Int_t key_test=GetKeyChamber(endcap,station,ring,chamber);
         if(key_test != key_chmb) cout<<"GetEffHits Error key_test key_chmb "<<key_test<<" "<<key_chmb<<"      "<<endcap<<" "<<station<<" "<<ring<<" "<<chamber<<endl;
         Int_t flag_trksegm=0;
         for(Int_t ilayer=0;ilayer<6;ilayer++) {
	  Int_t layer=ilayer+1;
          Int_t hvsgm=(*It).second[ilayer];
          if(hvsgm > 0) {
	   flag_trksegm++;
           Int_t keystrng=10*station+ring;
           Int_t nchmb=2*m_stationring_ncsc[keystrng];
           Int_t nhvsgm=m_stationring_nsegm[keystrng];

           Int_t nbinsx=nchmb;
           Float_t lowx=1.0;
           Float_t highx=nbinsx+1;
           Float_t x=-999.0;
           if(endcap==2) x=(Float_t)(m_stationring_ncsc[keystrng]-chamber+1)+0.5;
           if(endcap==1) x=(Float_t)(m_stationring_ncsc[keystrng]+chamber)+0.5;

           Int_t nbinsy=6*nhvsgm;
           Float_t lowy=1.0;
           Float_t highy=nbinsy+1;
           Float_t y=(layer-1)*nhvsgm+hvsgm;
           ss.str("");
           ss<<"ME"<<keystrng<<"_entries_eff";
           sx.str("");
           sx<<"ME"<<keystrng<<" CSC";
           // hist of hits
	   histos->fill2DHist(x,y,ss.str().c_str(),ss.str().c_str(),sx.str().c_str(),"HV segment","COLZ",nbinsx,lowx,highx,nbinsy,lowy,highy,1.0,"Eff"); 
             if(flag_trksegm==1) {
               nbinsy=nhvsgm;
               highy=nbinsy+1;
               y=hvsgm;
               ss.str("");
               ss<<"ME"<<keystrng<<"_trksegm_eff";
               sx.str("");
               sx<<"ME"<<keystrng<<" CSC";
	       // hist of track segments
	       histos->fill2DHist(x,y,ss.str().c_str(),ss.str().c_str(),sx.str().c_str(),"HV segment","COLZ",nbinsx,lowx,highx,nbinsy,lowy,highy,1.0,"Eff");
	     }
	  } //end of  if(hvsgm > 0)
	 }  //end of for(Int_t ilayer=0;ilayer<6;ilayer++)
         //cout<<endl;
       } // end for(std::map<UInt_t,std::vector <Int_t> >::iterator It=m_segments_chamber_hvg_eff_final.begin()
      } // end of  if(m_segments_chamber_hvg_eff_final.size() > 0)
    } // end of if(trackne == 1)
  } // end of if(m_nsegments_chamber_eff.size()>0)
}  // end of AnalysisGasGain::GetEffHits

Float_t AnalysisGasGain::GetSumQAtmCorr(HistMan* histos,Int_t station,Int_t ring,Float_t sumq,Int_t hour) {
  ostringstream ss, ss1;
  Float_t sumq_corr=sumq;

  if(m_atmpres.find(hour) != m_atmpres.end() && flag_atm > 0) {
    Float_t p=m_atmpres[hour];
    histos->fill1DHist(p,"Atm_pressure","","Atm. pressure, mbar","Entries",4,80, 940.0, 980.0,1.0,"Atm");

    ss.str("");
    ss<<"ME"<<station<<ring<<"_SumQ_vs_atm";
    ss1.str("");
    ss1<<"ME"<<station<<ring<<" SumQ";
    Int_t Ynbins=1000; Float_t Ylow=0.0; Float_t Yhigh=2000.0;
    //Float_t sumqp=sumq;
    Int_t key=10*station+ring;
    if(m_gasgain_atm_slope.find(key) == m_gasgain_atm_slope.end()) cout<<"GetSumQAtmCorr Error: wrong key for map gasgain_atm_slope "<<key<<endl;
    Double_t B=(Double_t)m_gasgain_atm_slope[key];
    B=(Float_t)fabs(B);
    Float_t sumqp=sumq * exp(B*(p-Pref));
    // if(sumqp >= Yhigh) put it in the last Ybin to have # entries in sliceY
    Float_t sumqh=sumqp;
    if(sumqh >= Yhigh) sumqh=Yhigh-(Yhigh-Ylow)/(2.0*(Float_t)Ynbins);
    histos->fill2DHist(p,sumqh,ss.str().c_str(),"","Atm. pressure, mbar",ss1.str().c_str(),"COLZ",80,940.0,980.0,Ynbins,Ylow,Yhigh,1.0,"Atm");
    sumq_corr=sumqp;
    if(m_atmpres.find(hour) == m_atmpres.end()) 
      cout<<"GetSumQAtmCorr Error: Atm. pressure not found, hour "<<hour<<endl;
  } // end of if(m_atmpres.find(hour) != m_atmpres.end() && flag_atm > 0)

  return sumq_corr;
}
/* ********************  CycleTree ************************************* */

void AnalysisGasGain::CycleTree(HistMan* histos) {

  m_RunEvent.clear();
  m_Run_usedevents.clear();
  m_Run_usedhits.clear();
  m_RunStart.clear();
  m_RunEnd.clear();
  m_RunRead.clear();

  //TFile *histrootfile = new TFile(histrootname.c_str(), "RECREATE");
  TFile *f = new TFile(ntuplename.c_str());
  TTree *tree = (TTree*)f->Get("cscRootMaker/Events");
  nentries = tree->GetEntries();
  cout<<"Total entries       "<<nentries<<endl;
  if(flag_stat>0) nentries=flag_stat;
  cout<<"Entries to read in  "<<nentries<<endl;
  cout<<endl;
  entries_analyzed=0;

  // Get branches
  TBranch *b_Run=tree->GetBranch("Run");
  TBranch *b_Event=tree->GetBranch("Event");
  TBranch *b_timeSecond=tree->GetBranch("timeSecond");

  TBranch *b_recHits2D_nRecHits2D=tree->GetBranch("recHits2D_nRecHits2D");
  TBranch *b_recHits2D_ID_endcap=tree->GetBranch("recHits2D_ID_endcap");
  TBranch *b_recHits2D_ID_station=tree->GetBranch("recHits2D_ID_station");
  TBranch *b_recHits2D_ID_ring=tree->GetBranch("recHits2D_ID_ring");
  TBranch *b_recHits2D_ID_chamber=tree->GetBranch("recHits2D_ID_chamber");
  TBranch *b_recHits2D_ID_layer=tree->GetBranch("recHits2D_ID_layer");
  TBranch *b_recHits2D_localX=tree->GetBranch("recHits2D_localX");
  TBranch *b_recHits2D_localY=tree->GetBranch("recHits2D_localY");
  TBranch *b_recHits2D_SumQ=tree->GetBranch("recHits2D_SumQ");
  TBranch *b_recHits2D_stripWidthAtHit=tree->GetBranch("recHits2D_stripWidthAtHit");
  TBranch *b_recHits2D_positionWithinStrip=tree->GetBranch("recHits2D_positionWithinStrip");
  TBranch *b_recHits2D_nearestStrip=tree->GetBranch("recHits2D_nearestStrip");
  
  TBranch *b_cscSegments_recHitRecord_endcap=tree->GetBranch("cscSegments_recHitRecord_endcap");
  TBranch *b_cscSegments_recHitRecord_station=tree->GetBranch("cscSegments_recHitRecord_station");
  TBranch *b_cscSegments_recHitRecord_ring=tree->GetBranch("cscSegments_recHitRecord_ring");
  TBranch *b_cscSegments_recHitRecord_chamber=tree->GetBranch("cscSegments_recHitRecord_chamber");
  TBranch *b_cscSegments_recHitRecord_layer=tree->GetBranch("cscSegments_recHitRecord_layer");
  TBranch *b_cscSegments_recHitRecord_localX=tree->GetBranch("cscSegments_recHitRecord_localX");
  TBranch *b_cscSegments_recHitRecord_localY=tree->GetBranch("cscSegments_recHitRecord_localY");

  TBranch *b_muons_cscSegmentRecord_nRecHits=tree->GetBranch("muons_cscSegmentRecord_nRecHits");
  TBranch *b_muons_cscSegmentRecord_endcap=tree->GetBranch("muons_cscSegmentRecord_endcap");
  TBranch *b_muons_cscSegmentRecord_station=tree->GetBranch("muons_cscSegmentRecord_station");
  TBranch *b_muons_cscSegmentRecord_ring=tree->GetBranch("muons_cscSegmentRecord_ring");
  TBranch *b_muons_cscSegmentRecord_chamber=tree->GetBranch("muons_cscSegmentRecord_chamber");
  TBranch *b_muons_cscSegmentRecord_localX=tree->GetBranch("muons_cscSegmentRecord_localX");
  TBranch *b_muons_cscSegmentRecord_localY=tree->GetBranch("muons_cscSegmentRecord_localY");

  // Set addresses
  b_Run->SetAddress(&fRun);
  b_Event->SetAddress(&fEvent);
  b_timeSecond->SetAddress(&ftimeSecond);

  b_recHits2D_nRecHits2D->SetAddress(&frecHits2D_nRecHits2D);
  b_recHits2D_ID_endcap->SetAddress(frecHits2D_ID_endcap); // no & for array
  b_recHits2D_ID_station->SetAddress(frecHits2D_ID_station);
  b_recHits2D_ID_ring->SetAddress(frecHits2D_ID_ring);
  b_recHits2D_ID_chamber->SetAddress(frecHits2D_ID_chamber);
  b_recHits2D_ID_layer->SetAddress(frecHits2D_ID_layer);
  b_recHits2D_localX->SetAddress(frecHits2D_localX);
  b_recHits2D_localY->SetAddress(frecHits2D_localY);
  b_recHits2D_SumQ->SetAddress(frecHits2D_SumQ); 
  b_recHits2D_stripWidthAtHit->SetAddress(frecHits2D_stripWidthAtHit);
  b_recHits2D_positionWithinStrip->SetAddress(frecHits2D_positionWithinStrip);
  b_recHits2D_nearestStrip->SetAddress(frecHits2D_nearestStrip);

  b_cscSegments_recHitRecord_endcap->SetAddress(&fcscSegments_recHitRecord_endcap);
  b_cscSegments_recHitRecord_station->SetAddress(&fcscSegments_recHitRecord_station);
  b_cscSegments_recHitRecord_ring->SetAddress(&fcscSegments_recHitRecord_ring);
  b_cscSegments_recHitRecord_chamber->SetAddress(&fcscSegments_recHitRecord_chamber);
  b_cscSegments_recHitRecord_layer->SetAddress(&fcscSegments_recHitRecord_layer);
  b_cscSegments_recHitRecord_localX->SetAddress(&fcscSegments_recHitRecord_localX);
  b_cscSegments_recHitRecord_localY->SetAddress(&fcscSegments_recHitRecord_localY);

  b_muons_cscSegmentRecord_nRecHits->SetAddress(&fmuons_cscSegmentRecord_nRecHits);
  b_muons_cscSegmentRecord_endcap->SetAddress(&fmuons_cscSegmentRecord_endcap);
  b_muons_cscSegmentRecord_station->SetAddress(&fmuons_cscSegmentRecord_station);
  b_muons_cscSegmentRecord_ring->SetAddress(&fmuons_cscSegmentRecord_ring);
  b_muons_cscSegmentRecord_chamber->SetAddress(&fmuons_cscSegmentRecord_chamber);
  b_muons_cscSegmentRecord_localX->SetAddress(&fmuons_cscSegmentRecord_localX);
  b_muons_cscSegmentRecord_localY->SetAddress(&fmuons_cscSegmentRecord_localY);

  fcscSegments_recHitRecord_endcap  = 0; 
  fcscSegments_recHitRecord_station = 0; 
  fcscSegments_recHitRecord_ring    = 0;  
  fcscSegments_recHitRecord_chamber = 0; 
  fcscSegments_recHitRecord_layer   = 0; 
  fcscSegments_recHitRecord_localX  = 0; 
  fcscSegments_recHitRecord_localY  = 0;

  fmuons_cscSegmentRecord_nRecHits  = 0;
  fmuons_cscSegmentRecord_endcap    = 0;
  fmuons_cscSegmentRecord_station   = 0;
  fmuons_cscSegmentRecord_ring      = 0;
  fmuons_cscSegmentRecord_chamber   = 0;
  fmuons_cscSegmentRecord_localY    = 0;
  fmuons_cscSegmentRecord_localX    = 0;

  // *********************************************
  // ***  Cycling over tree
  // *********************************************

  for(Int_t ient=0;ient<nentries;ient++) {

     b_Run->GetEntry(ient);
     b_Event->GetEntry(ient);
     b_timeSecond->GetEntry(ient);

     b_recHits2D_nRecHits2D->GetEntry(ient);
     b_recHits2D_ID_endcap->GetEntry(ient);
     b_recHits2D_ID_station->GetEntry(ient);
     b_recHits2D_ID_ring->GetEntry(ient);
     b_recHits2D_ID_chamber->GetEntry(ient);
     b_recHits2D_ID_layer->GetEntry(ient);
     b_recHits2D_localX->GetEntry(ient);
     b_recHits2D_localY->GetEntry(ient);
     b_recHits2D_SumQ->GetEntry(ient);
     b_recHits2D_stripWidthAtHit->GetEntry(ient);
     b_recHits2D_positionWithinStrip->GetEntry(ient);
     b_recHits2D_nearestStrip->GetEntry(ient);
     
     b_cscSegments_recHitRecord_endcap->GetEntry(ient);
     b_cscSegments_recHitRecord_station->GetEntry(ient);
     b_cscSegments_recHitRecord_ring->GetEntry(ient);
     b_cscSegments_recHitRecord_chamber->GetEntry(ient);
     b_cscSegments_recHitRecord_layer->GetEntry(ient);
     b_cscSegments_recHitRecord_localX->GetEntry(ient);
     b_cscSegments_recHitRecord_localY->GetEntry(ient);

     b_muons_cscSegmentRecord_nRecHits->GetEntry(ient);
     b_muons_cscSegmentRecord_endcap->GetEntry(ient);
     b_muons_cscSegmentRecord_station->GetEntry(ient);
     b_muons_cscSegmentRecord_ring->GetEntry(ient);
     b_muons_cscSegmentRecord_chamber->GetEntry(ient);
     b_muons_cscSegmentRecord_localX->GetEntry(ient);
     b_muons_cscSegmentRecord_localY->GetEntry(ient);

     m_nRecHitlayer.clear();
     m_nRecHitchamber.clear();
     m_cscSegments_recHitRecordX.clear();
     m_cscSegments_recHitRecordY.clear();
     m_nsegments_chamber.clear();
     m_nsegments_chamber_eff.clear();
     m_segments_chamber_hvg_eff.clear();
     m_segments_chamber_hvg_eff_final.clear();
     m_muon_segm.clear();
     m_Single_cscSegments_recHitRecordX.clear();
     m_Single_cscSegments_recHitRecordY.clear();
     m_cscSegments_single_trk_recHitRecord.clear();
     m_cscSegments_single_trk_recHitRecord_final.clear();


     // Run, Event, Start, End
     Int_t key_run=(Int_t)fRun;
    
     if(m_RunRead.find(key_run) == m_RunRead.end())
       m_RunRead[key_run]=0;
     m_RunRead[key_run]=m_RunRead[key_run]+1;

     Int_t flag_run=0;
     if(m_Run.size() == 0) flag_run=1;
     if(m_Run.size() > 0 && m_Run.find(key_run) != m_Run.end()) flag_run=1;

     if(flag_run==1) {
     if(m_RunEvent.find(key_run) == m_RunEvent.end()) {
       m_RunEvent[key_run]=0;
       m_Run_usedevents[key_run]=0;
       m_Run_usedhits[key_run]=0;
       // get max number, it should be 4294967295 for unsigned int
       m_RunStart[key_run]=std::numeric_limits<unsigned int>::max();       
       m_RunEnd[key_run]=0;
     }
     m_RunEvent[key_run]=m_RunEvent[key_run]+1;
     if(ftimeSecond>m_RunEnd[key_run]) m_RunEnd[key_run]=ftimeSecond;
     if(ftimeSecond<m_RunStart[key_run]) m_RunStart[key_run]=ftimeSecond;

     //************************************************************************
     // Check the presence of not empty hits array and seg,ent, track vectors
     //************************************************************************

     Int_t recsegtrk=0;
     if(frecHits2D_nRecHits2D > 0) recsegtrk=recsegtrk+1;
     if(fcscSegments_recHitRecord_endcap->size() > 0) recsegtrk=recsegtrk+2;
     if(fmuons_cscSegmentRecord_nRecHits->size() > 0) {
       Int_t ncscsegm=0;
       for(UInt_t i=0;i<fmuons_cscSegmentRecord_nRecHits->size();i++) 
	 if((*fmuons_cscSegmentRecord_nRecHits)[i].size() > 0) ncscsegm++; 
       if(ncscsegm > 0) recsegtrk=recsegtrk+4;
     }
     if(flag_test) histos->fill1DHist((Float_t)recsegtrk,"recsegtrk","","Bit 1-RecHits2D, Bit 2-Segments and Bit 3-Tracks per event","Entries",4,8,0.0,8.0,1.0,"Test");
  
     if(recsegtrk==7) { //Analyse event when there are hits&&segments&&tracks
      if(ient<flag_print) cout<<endl<<"*** "<<ient+1<< " Event "<<fEvent<<endl;

     entries_analyzed++;
     GetRecHits(histos);

     //************************************************************************
     // Cycling thru segments in fcscSegments_recHitRecord_*, 
     // put their rechits X,Y local into 
     // maps m_cscSegments_recHitRecordX,*Y[key_segment][0-5], 0-5 are layers
     // and count # of segments per chamber in m_nsegments_chamber[chamber]
     //************************************************************************

     GetSegments(histos);

     //*******************************************************************
     // Cycling thru tracks in event and segments in them, put to map  
     // m_cscSegments_single_trk_recHitRecord[key_layer][0-2]
     //corresponding rechits
     //*******************************************************************

     GetTracks(histos);

     //**************************************
     //*** cycling over recHits2D_nRecHits to find SumQ and put it into
     //*** map m_cscSegments_single_trk_recHitRecord[key_layer][0-2]
     //***************************************

     GetRecHitsSumQ(histos);

     if(m_cscSegments_single_trk_recHitRecord_final.size() > 0) {
         m_Run_usedevents[key_run]=m_Run_usedevents[key_run]+1;
         m_Run_usedhits[key_run]=m_Run_usedhits[key_run]+(Int_t)m_cscSegments_single_trk_recHitRecord_final.size();
     }

     //**********************************************************************
     // Cycling thru  m_cscSegments_single_trk_recHitRecord_final to fill SumQ
     // histograms in HV segments
     //**********************************************************************

     if(m_cscSegments_single_trk_recHitRecord_final.size() > 0) 
        FillSumQHists(histos); 

     //**********************************************************************
     // Look at resolution
     //**********************************************************************
    
     if(m_cscSegments_single_trk_recHitRecord_final.size() > 0 && flag_resid>0)
       CscResolution(histos);

     //**********************************************************************
     // Get hits for efficiency estimate
     //**********************************************************************
     
     if(flag_eff) GetEffHits(histos);

     } // end of if(recsegtrk==7)
     } // end of if(flag_run==1)
  } // end of  for(Int_t ient=0;

  tree->ResetBranchAddresses();

  //************************************************************************
  // End of tree analysis printout
  //**************************************************************************

  Int_t cnt=0,cnt_usedhits=0;
  if(m_RunEvent.size() > 0) cout<<endl;
  cout<<"Read in runs with events, m_RunRead.size() "<<m_RunRead.size()<<endl;
  for(std::map<Int_t,Int_t>::iterator It=m_RunRead.begin(); It!= m_RunRead.end();++It) {
    cnt++;
    cout<<cnt<<"   "<<(*It).first<<" "<<(*It).second<<endl;
  }
  cnt=0;
  cout<<endl;
  cout<<"Used runs, m_RunEvent.size() "<< m_RunEvent.size()<<endl;
  if(m_RunEvent.size() == 0 ) cout<<endl;
  if(m_RunEvent.size() > 0 ) {
  Int_t cnt_readin=0,cnt_used=0;
  for(std::map<Int_t,Int_t>::iterator It=m_RunEvent.begin(); It!= m_RunEvent.end();++It) {
     Int_t key=(*It).first;
     cnt++;     
     Int_t dur=(Int_t)(m_RunEnd[key]-m_RunStart[key]);
     cnt_readin=cnt_readin+m_RunEvent[key];
     cnt_used=cnt_used+m_Run_usedevents[key];
     cnt_usedhits=cnt_usedhits+m_Run_usedhits[key];
     cout<<cnt<<" Run  Events  Start  End  Duration  Used events  Used hits "<<key<<" "<<(*It).second<<" "<<m_RunStart[key]<<" "<<m_RunEnd[key]<<" "<<dur<<" "<<m_Run_usedevents[key]<<" "<<m_Run_usedhits[key]<<endl;
  }
  cout<<endl;
  cout<<"--------------------------------------------------"<<endl;
  cout<<"Total analyzed events (with hits, segments and tracks) "<<entries_analyzed<<" from "<<cnt_readin<<" read in"<<endl;
  cout<<"Total read in hits "<<nhitstotal<<endl;
  cout<<"Total read in hits with SumQ>0 "<<nhitstotalsumq<<" "<<100.0*(Float_t)nhitstotalsumq/(Float_t)nhitstotal<<"%"<<endl;
  cout<<"Total used hits "<<cnt_usedhits<<" in "<<cnt_used<<" used events  from "<<entries_analyzed<<" analyzed events in "<<m_RunEvent.size()<<" runs"<<endl;
  cout<<endl;
  }
  cout<<"End of AnalysisGasGain::CycleTree "<<endl;

  //*************************************************************************
  // write and close output file with hists always first in case if hists
  // were stored in f directory
  //************************************************************************

  if(cnt_usedhits > 0) {
    TFile *histrootfile = new TFile(histrootname.c_str(), "RECREATE");
    histos->writeHists(histrootfile);
    histrootfile->Close();
  }
  f->Close();
}

