void  build_analysisgasgain() {
R__LOAD_LIBRARY(HistMan_cxx.so);
gROOT->ProcessLine(".L AnalysisGasGain.cxx++");
}
