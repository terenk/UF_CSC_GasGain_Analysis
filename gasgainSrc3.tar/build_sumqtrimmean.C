void  build_sumqtrimmean () {
R__LOAD_LIBRARY(HistMan_cxx.so);
gROOT->ProcessLine(".L SumQTrimMean.cxx++");
}
