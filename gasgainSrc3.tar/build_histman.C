void  build_histman () {
gROOT->ProcessLine(".L HistMan.cxx++");
}
