#ifndef ROOT_SumQTrimMean
#define ROOT_SumQTrimMean

#include "TFile.h"
#include <map>
#include <string>
#include "HistMan.h"

class SumQTrimMean : public TObject {

private:

  string  inhistname;      // input hist  file
  string  badhvsgmname;    // input text file with bad HV segments
  string  outliercuts;     // input text file with cuts for outliers
  Double_t statpar;        // Statistics parameter for TrimmedMean
  Double_t scale;          // scaling factor to reduce gas gain
  string  histrootname;    // output ROOT file with hists

  Int_t ntype[9],nsegm[9],ncsc[9];
  Int_t cnt,cnt_hv,cnt_hv_nodata,cnt_gasgaingood,cnt_gasgainout,
        cnt_gasgainsmallstat,cnt_gasgainbad;
  Float_t ref_gasgain_me11,glob_ref_gasgain_non_me11,
          glob_ref_gasgain_non_me11_inner, glob_ref_gasgain_non_me11_outer;
  Float_t dhvME11cut[2],rgg0ME11cut[2],
          dhvnonME11cut[2],rgg0nonME11innercut[2],rgg0nonME11outercut[2];
public:

  SumQTrimMean();
  virtual ~SumQTrimMean();

  void Setup(string,string,string,Double_t,Double_t,string);

  Double_t GetTrimmedMean(TH1D*);
  Double_t GetTrimmedMeanError(TH1D*);
  void   GetHVSegmTrMean(TFile *);
  Int_t  GetEndcapFromKey(Int_t);
  Int_t  GetStationFromKey(Int_t);
  Int_t  GetRingFromKey(Int_t);
  Int_t  GetCscFromKey(Int_t);
  Int_t  GetLayerFromKey(Int_t);
  Int_t  GetSegmFromKey(Int_t);
  void   MapsToHist(HistMan*);
  void  HVCorr(HistMan*);
  void PlotGraph();

  void Analyze(HistMan*);

ClassDef(SumQTrimMean,1) 
};

#endif
