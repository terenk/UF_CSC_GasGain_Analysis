#ifndef ROOT_AnalysisGasGain
#define ROOT_AnalysisGasGain

#include "HistMan.h"
#include "linfitcalc.h"

class AnalysisGasGain : public TObject {

private:

  string  runlistname;     // list of runs
  string  atmpressname;    // list of atm pressure
  string  gasgain_atm_slope; // list of gas gain vs atm. slopes
  string  ntuplename;      // input ntuple file
  string  histrootname;    // output ROOT file with hists

  Int_t nentries;          // Tree entries (events)
  Int_t entries_analyzed;  // # of analyzed entries (events)
  Int_t nhitstotal;        // total # of read in hits
  Int_t nhitstotalsumq;    // total # of read in hits with SumQ>0

  Int_t flag_stat;         // 0 - use all entries,>0 - use flag_stat statistics
  Int_t flag_print;        // 0-do not print debug info, >0 - print it
  Int_t cnt_print;         // is set to 0 in Setup, to count number of prints

  Float_t Pref;            // Reference atm. pressure for gas gain correction

  // flags to fill hists in folders
  Int_t flag_atm,flag_test,flag_hists,flag_resid,flag_histssegm,flag_eff;

  // initial values
  std::vector<Double_t> dzero3,dinit6;
  std::vector<Int_t> izero6;  

  // Variables for tree
  
  ULong64_t   fEvent,fRun;
  UInt_t      ftimeSecond;

  Int_t       frecHits2D_nRecHits2D;
  Int_t       frecHits2D_ID_endcap[10000], frecHits2D_ID_station[10000],
              frecHits2D_ID_ring[10000],   frecHits2D_ID_chamber[10000], 
              frecHits2D_ID_layer[10000];
  Double_t    frecHits2D_localX[10000],  frecHits2D_localY[10000],    
              frecHits2D_SumQ[10000],
              frecHits2D_stripWidthAtHit[10000],
              frecHits2D_positionWithinStrip[10000];
  Int_t       frecHits2D_nearestStrip[10000];

  vector<vector<Double_t> > *fcscSegments_recHitRecord_endcap;
  vector<vector<Double_t> > *fcscSegments_recHitRecord_ring;
  vector<vector<Double_t> > *fcscSegments_recHitRecord_station;
  vector<vector<Double_t> > *fcscSegments_recHitRecord_chamber;
  vector<vector<Double_t> > *fcscSegments_recHitRecord_layer;
  vector<vector<Double_t> > *fcscSegments_recHitRecord_localX;
  vector<vector<Double_t> > *fcscSegments_recHitRecord_localY;

  std::vector< std::vector<Double_t> > *fmuons_cscSegmentRecord_nRecHits;
  std::vector< std::vector<Double_t> > *fmuons_cscSegmentRecord_endcap;
  std::vector< std::vector<Double_t> > *fmuons_cscSegmentRecord_station;
  std::vector< std::vector<Double_t> > *fmuons_cscSegmentRecord_ring;
  std::vector< std::vector<Double_t> > *fmuons_cscSegmentRecord_chamber;
  std::vector< std::vector<Double_t> > *fmuons_cscSegmentRecord_localY;
  std::vector< std::vector<Double_t> > *fmuons_cscSegmentRecord_localX;

  // Low and High Y local coordinates (cm) of the HV segments in CSC layers
  Float_t  me12YlocHVsgmLow[3],   me12YlocHVsgmHigh[3],
           me13YlocHVsgmLow[3],   me13YlocHVsgmHigh[3], 
           me21YlocHVsgmLow[3],   me21YlocHVsgmHigh[3], 
           me31YlocHVsgmLow[3],   me31YlocHVsgmHigh[3],
           me41YlocHVsgmLow[3],   me41YlocHVsgmHigh[3],
           me234_2YlocHVsgmLow[5],me234_2YlocHVsgmHigh[5];

public:

  AnalysisGasGain();
  virtual ~AnalysisGasGain();

  void Setup(Int_t,Int_t,Int_t,Int_t,Int_t,Int_t,Int_t,Int_t,string,string,string,string,string);

  void SetupPrint();

  Int_t doHVsegment(Float_t, Int_t, Int_t, Int_t);

  void Analyze(HistMan*);

  Int_t GetKeyChamber(Int_t &,Int_t &,Int_t &,Int_t &);
  Int_t GetKeyLayer(Int_t &,Int_t &,Int_t &,Int_t &,Int_t &);
  UInt_t GetKeySegm(Int_t &,Int_t &,Int_t &,Int_t &,Int_t &);
  UInt_t GetKeyTrkSegm(Int_t &,Int_t &,Int_t &,Int_t &,Int_t &,Int_t &);

  void GetRecHits(HistMan*);
  void GetSegments(HistMan*);
  void GetTracks(HistMan*);
  void GetRecHitsSumQ(HistMan*);
  void FillSumQHists(HistMan*);
  Int_t SameStripBin(std::vector <Float_t>);
  void CscResolution(HistMan*);
  void GetEffHits(HistMan*);
  Float_t GetSumQAtmCorr(HistMan*,Int_t,Int_t,Float_t,Int_t);
  void CycleTree(HistMan*);

ClassDef(AnalysisGasGain,1) 
};

#endif
