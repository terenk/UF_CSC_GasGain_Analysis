#ifndef LINFITCALC_H
#define LINFITCALC_H

void linfit(int n,float x[],float y[],float er[],float &a1,float &a2,
            float ft[],float &da1,float &da2,float &da12,float chi2[],
            float &chi2t)
{
/*
c
c *****  linear fit from direct calculation, no iterations
c
c       n       - # of exp. points to fit
c       x,y,er  - arrays of argument X, experim. value Y and its error ER
c       a1,a2   - coeff.  in A + Bx
c       ft      - ft = A + Bx
c       da1,da2 - errors of coeff. a1,a2
c       da12     - correl error of a1,a2
c       chi2    - chi2- contribution array of exp.points
c       chi2t   - total chi2
c
c       Source - "Statistics" by D.J.Hudson
c   Jan 2, 2001 - Fermilab - modified from linfit(...) in th_bt_pn_res.kumac
*/

double xdbl,ydbl,erdbl,
      s1=0.,sx=0.,sy=0.,sxx=0.,sxy=0.,w,f,d;
int   i;

   if(n >= 2)
   {
     for(i=0; i<n; i++)
     {
       if(er[i] > 0.)
       {
                xdbl=x[i];
                ydbl=y[i];
                erdbl=er[i];
                w=1./(erdbl*erdbl);
                s1=s1+w;
                sx=sx+xdbl*w;
                sy=sy+ydbl*w;
                sxy=sxy+xdbl*ydbl*w;
                sxx=sxx+xdbl*xdbl*w;
       }
     }

     d=s1*sxx-sx*sx;
     if(d != 0.)
     {
        a1=(sy*sxx-sx*sxy)/d;
        a2=(s1*sxy-sx*sy)/d;
        da1=sxx/d;
        da2=s1/d;
        da12=-sx/d;
        if(da1 < 0.) da1=-da1;
        if(da2 < 0.) da2=-da2;
//        if(da12 < 0.) da12=-da12;
        da1=sqrt(da1);
        da2=sqrt(da2);
//        da12=sqrt(da12);

        chi2t=0.0;
        for(i=0;i<n; i++)
        {
                ft[i]=a1+a2*x[i];
                f=a1+a2*x[i];
                w=1./(er[i]*er[i]);
                chi2[i]=(f-y[i])*(f-y[i])*w;
                chi2t=chi2t+chi2[i];
        }
     }
   }
}

#endif
