//
// Macros to run SumQTrimMean for result of AnalysisGasGain.
// Called in  script script_sumqtrimmean.
//

void sumqtrimmean(string ntuplename,string badhvsgm,string cuts,Float_t statpar,Float_t scale,string histroot) {

     R__LOAD_LIBRARY($SRC/HistMan_cxx.so);
     R__LOAD_LIBRARY($SRC/SumQTrimMean_cxx.so);

     HistMan *histos = new HistMan();
     SumQTrimMean *anl=new SumQTrimMean();

     anl->Setup(ntuplename,badhvsgm,cuts,statpar,scale,histroot);
     anl->Analyze(histos);
    
     delete histos;
     delete anl; 
}
