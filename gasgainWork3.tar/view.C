{
gStyle->SetPalette(1,0);
gROOT->SetStyle("Plain");

TFile f("sumqtrimmean.root");
f.GetListOfKeys()->Print();
f.ls();
TBrowser browser;
}
