
//
// Macros to run AnalysisGasGain for single input ntuple.
// Called in  script script_gasgain
//
void analysisgasgain(Int_t fstat,Int_t fprint,Int_t fatm,Int_t ftest,Int_t fhists,Int_t fresid,Int_t fhistssegm,Int_t feff,string runlistname,string atmpressname,string gasgain_atm_slope_list,string ntuplename,string histroot) {

  R__LOAD_LIBRARY($SRC/HistMan_cxx.so);
  R__LOAD_LIBRARY($SRC/AnalysisGasGain_cxx.so);

  HistMan *histos = new HistMan();
  AnalysisGasGain *anl=new AnalysisGasGain();

  anl->Setup(fstat,fprint,fatm,ftest,fhists,fresid,fhistssegm,feff,runlistname,atmpressname,gasgain_atm_slope_list,ntuplename,histroot);
  anl->Analyze(histos);

  delete histos;
  delete anl; 
}
